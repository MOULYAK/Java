function varargout = final(varargin)
% FINAL M-file for final.fig
%      FINAL, by itself, creates a new FINAL or raises the existing
%      singleton*.
%
%      H = FINAL returns the handle to a new FINAL or the handle to
%      the existing singleton*.
%
%      FINAL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FINAL.M with the given input arguments.
%
%      FINAL('Property','Value',...) creates a new FINAL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before final_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to final_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help final

% Last Modified by GUIDE v2.5 15-Apr-2016 12:15:34

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @final_OpeningFcn, ...
                   'gui_OutputFcn',  @final_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before final is made visible.
function final_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to final (see VARARGIN)

% Choose default command line output for final
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes final wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = final_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output=hObject;
[a b]=uigetfile({'*.*'});
A=imread([b a]);
B=rgb2gray(A);

%gr=input('enter threshold value');
l=B>80;

%handles.bw=l;
BW2 = bwareaopen(l,50);
imshow(A,'Parent' ,handles.axes1);
guidata(hObject,handles);


l=bwlabel(BW2);

value=0;
r1=0;
r2=0;
r5=0;
r10=0;


for j=1:max(max(l))
    [row ,col]=find(l==j);
    len=max(row)-min(row)+2;
    breadth=max(col)-min(row)+2;
    target=uint8(zeros([len breadth]));
    sy=min(col)-1;
    sx=min(row)-1;
    
    for i=1:size(row,1)
        x=row(i,1)-sx;
        y=col(i,1)-sy;
        target(x,y)=B(row(i,1),col(i,1));
       
        
    end
   % mytitle=strcat('object value:',num2str(j));
   % figure,imshow(target);title(mytitle);
    
             
        
end
blobs=regionprops(logical(l),'all')
allareas=[blobs.Area]
%me=[blobs.Centroid]


for v=1:max(max(l))
    if (allareas(v)==9167)||(allareas(v)==9200)||(allareas(v)==17766)||(allareas(v)==16750)||(allareas(v)==17802)||(allareas(v)==14114)
        value=value+2;
        r2=r2+1;
    end
    if(allareas(v)>=14534)&&(allareas(v)<=14731)
        value=value+1;
        r1=r1+1;
    end
    if(allareas(v)>=9201)&&(allareas(v)<=10436)||(allareas(v)>=8546)&&(allareas(v)<=9166)||(allareas(v)==16888)||(allareas(v)==16547)
        value=value+5;
        r5=r5+1;
    end
     if(allareas(v)==138461)
        value=value+10;
        r10=r10+1;
    end
    
    
end
set(handles.text5,'String',r2);
set(handles.text6,'String',r1);
set(handles.text7,'String',r5);
set(handles.text8,'String',r10);

set(handles.text2,'string',value);
%imshow(handles.label,'Parent',handles.axes2);

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%handles.output=hObject;
%inverse_binary=not(handles.bw);
%BW2 = bwareaopen(inverse_binary,50);


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output=hObject;
[c d]=uigetfile({'*.*'});
M=imread([d c]);
N=rgb2gray(M);

%gr=input('enter threshold value');
p=N>80;

%handles.bw=l;
BW3 = bwareaopen(p,50);
imshow(M,'Parent' ,handles.axes4);
guidata(hObject,handles);


l2=bwlabel(BW3);


value2=0;
c1=0;
c2=0;
c5=0;
c10=0;

for j=1:max(max(l2))
    [row ,col]=find(l2==j);
    len=max(row)-min(row)+2;
    breadth=max(col)-min(row)+2;
    target=uint8(zeros([len breadth]));
    sy=min(col)-1;
    sx=min(row)-1;
    
    for i=1:size(row,1)
        x=row(i,1)-sx;
        y=col(i,1)-sy;
        target(x,y)=N(row(i,1),col(i,1));
       
        
    end
   % mytitle=strcat('object value:',num2str(j));
   % figure,imshow(target);title(mytitle);
    
             
        
end
blobs=regionprops(logical(l2),'all')
allareas=[blobs.Area]
%me=[blobs.Centroid]


for v=1:max(max(l2))
    if (allareas(v)==9167)||(allareas(v)==9200)||(allareas(v)==17766)||(allareas(v)==16750)||(allareas(v)==17802)||(allareas(v)==14114)
        value2=value2+2;
        c2=c2+1;
    end
    if(allareas(v)>=14534)&&(allareas(v)<=14731)
        value2=value2+1;
        c1=c1+1;
    end
    if(allareas(v)>=9201)&&(allareas(v)<=10436)||(allareas(v)>=8546)&&(allareas(v)<=9166)||(allareas(v)==16888)||(allareas(v)==16547)
        value2=value2+5;
        c5=c5+1;
    end
     if(allareas(v)==138461)
        value2=value2+10;
        c10=c10+1;
    end
    
    
end
            
      r2=get(handles.text5,'String');
      r1=get(handles.text6,'String');
      r5=get(handles.text7,'String');
      r10=get(handles.text8,'String');

      if (str2double(r1)==c1)&&(str2double(r2)==c2)&&(str2double(r10)==c10)&&(str2double(r5)==c5)
          result='two images are matched';
      else
          result='two images are not matched';
      end
             set(handles.text4,'string',result);
             
%set(handles.text2,'string',value);
%imshow(handles.label,'Parent',handles.axes2);
