<html>
<body>
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

if(isset($_GET['id']))
{
	
$id=$_GET['id'];
echo"$id";
$qry=("delete from blogmaster where Blog_ID='$id'");
//mysql_select_db('blog');
$res=mysqli_query($conn,$qry) ;
//echo "$res" or die(mysql_error());
if($res)
{	
header('location:controls.php');
}
else
{
	echo"error deleting records".mysql_error($conn);
}
}
?>
</body>
</html>