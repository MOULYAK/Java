
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
//echo "Connected successfully";


$bname=$_POST['title'];
$cate=$_POST['cate'];
//$pic=$_POST['image'];
$desc=$_POST['desc'];
//$uname=$_POST['fname'];
$author=$_SESSION['fname'];
$mail=$_SESSION['mail'];
$createdate=date('y-m-d h:i:s');
if(isset($_POST['upload']))
{
			$conn = mysql_connect("localhost","root","");
			mysql_select_db("blog",$conn);

			$upload_image=addslashes($_FILES["image"][ "name" ]);
			if($upload_image=='')
			{
				echo "<script>alert('Please Select an Image')</script>";
				exit();
			}
			else
			{
					$folder="myimages";

					move_uploaded_file(addslashes($_FILES["image"]["tmp_name"]), "$folder".addslashes($_FILES["image"]["name"]));
					$sql="select UserID from reg where Email='$mail'";
					$res=mysql_query($sql,$conn);
					while ($row = mysql_fetch_assoc($res)) 
					{
					$id= $row['UserID'];
					$_SESSION['UserID']=$id;
					}
					//echo "$id";
					$insert_path="insert into blogmaster(Blog_ID,UserID,BlogTitle,BlogDesc,BlogCate,BlogAuthor,Blog_is_active,CreationDate,UpdateDate,Name,img) values('','$id','$bname','$desc','$cate','$author','','$createdate','','$folder','$upload_image')";
					//echo $insert_path;
					$var=mysql_query($insert_path) or die(mysql_error());
					//echo $var;
						if ($var)
						{
					header("location: admin.php");
							//echo "New record created successfully ....your blog is stored";
						}
						
			}
					
}


?>