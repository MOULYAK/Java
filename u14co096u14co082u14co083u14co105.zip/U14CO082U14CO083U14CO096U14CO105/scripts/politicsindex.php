<html>
    <head>
    	<title>Homepage of blog</title>
    	<meta name="viewport" content="width=device-width, initial-scale=1"/>
      	<link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
      	<link type="text/css" rel="stylesheet" href="../css/style.css">
    </head>
    <body>
	<?php
	session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}


?>
<nav>
			<div class="nav-wrapper z-depth-1">
				<div class="container">
					<div class="col s12 m12 l12">
				        <a href="#!" class="brand-logo">Daily News</a>
				        <ul class="side-nav">
						<li><a href="homepage.php">homepage</a></li>
						<li>
				        <a href="login.html" ><i class="mdi-action-view-module left"></i>Login</a>
						</li>
				          	
				        </ul>
		      		</div>
				</div>
		  	</div>
		</nav>
		

		<div class="container">
			<div class="row">
		      <div class="col s12 m8 l8">
			  
		      
<?php	
		
$sql = "SELECT Blog_ID,BlogTitle,BlogDesc,BlogCate,CreationDate,BlogAuthor,Name,img,Blog_is_active FROM blogmaster WHERE BlogCate='Politics' order by CreationDate Desc";
$result = mysqli_query($conn,$sql);
if(! $result )
{
  die('Could not get data: ' . mysql_error());
}

?>
<?php
while($row = mysqli_fetch_assoc($result))
{	if($row['Blog_is_active']==1)
	{
		$a=$row['Blog_ID'];
	?>

   <div class="post-index z-depth-1">
   
   <?php
			$image_name=$row['Name'];
			$image_path=$row['img'];

			
		echo "<h5>{$row['BlogTitle']}</h5> ".
		"  {$row['CreationDate']}<br>";
		echo "<img src=../".$image_name."/".$image_path." height=250 width=100%><br>";
		 
		 echo 
		 "<i><b>CATEGORY:</i></b>{$row['BlogCate']} <br> ".
		 "<i><b>Author:</i></b>{$row['BlogAuthor']}<br>".
		 "<i><b>DESCRIPTION: </i></b>{$row['BlogDesc']} <br>";
		 echo "<br> <br>";
		 ?>
		 <div class="post-index z-depth-1">
	<ul class="collection">
	<?php 	
		$query="select * from comment where BID='$a'";
		$res=mysqli_query($conn,$query);
		
		while($ro=mysqli_fetch_assoc($res))
		{
			echo"
				<li class 'collection-item'>
				<p class='com_title'>Comment by:".$ro['fname']."
				<p class='com_body'>".$ro['comm']."</p>		
				</li>
				";
		}
		
		?>
		</ul>
		</div>
		 
</div>
		 <?php
		 
}
}?>
						
		      		
		      	
				
		      </div>
<div class="col s12 m4 l4">
		      	
		      	<div class="widget-item z-depth-1">
		      		<b>Categories</b>
		      		<div>
		      			<ul class="collection">
					        <a href="entertainmentindex.php" class="collection-item">Entertainment</a>
					        <a href="politicsindex.php" class="collection-item">Politics</a>
					        
					        <a href="economyindex.php" class="collection-item">Economy</a>
					        
					        
							<a href="sportsindex.php" class="collection-item">Sports</a>
					      </ul>
		      		</div>
		      	</div>
		      </div>
		    </div>
        </div>

  	  	<footer>
          <div class="footer-copyright">
            <div class="container">
            © 2014 Copyright Text
            <a class="grey-text text-lighten-4 right" href="#!">About Me</a>
            </div>
          </div>
        </footer>

    	<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      	<script type="text/javascript" src="js/materialize.min.js"></script>
      	<script type="text/javascript">
      		$(document).ready(function(){
		      $('.materialboxed').materialbox();
		    });

		    setInterval(function(){ toast('New Post', 4000) }, 7000);
      	</script>
		
    </body>
	
</html>

