<html>
    <head>
    	<title>Homepage of NEWS</title>
    	<meta name="viewport" content="width=device-width, initial-scale=1"/>
      	<link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
      	<link type="text/css" rel="stylesheet" href="../css/style.css">
    </head>
    <body>
	<?php
	session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}


?>
<nav>
    <div class="nav-wrapper">
      <a href="bloggerinfo.php" class="brand-logo right">Welcome,<?php echo "$_SESSION[fname]";?></a>
      <ul id="nav-mobile" class="left hide-on-med-and-down">
        <li><a href="homepageuser.php">All news</a></li>
        <li><a href="myblogs.php">My news</a></li>
		<li><a href="userpage.php">Write new news</a></li>
		<li><a href="logout.php"><i class="mdi-action-view-module left"></i>logout</a></li>
        
      </ul>
    </div>
  </nav>
  
		

		<div class="container">
			<div class="row">
		      <div class="col s12 m8 l8">
			  
		      
<?php	
$sql = "SELECT Blog_ID,BlogTitle,BlogDesc,BlogCate,CreationDate,BlogAuthor,Name,img,Blog_is_active FROM blogmaster order by CreationDate Desc";
$result =mysqli_query($conn,$sql);

if(! $result )
{
  die('Could not get data: ' . mysql_error());
}

?>
<?php
while($row =mysqli_fetch_assoc($result))
{
	if($row['Blog_is_active']==1)
	{
		$a=$row['Blog_ID'];
		
	?>

   <div class="post-index z-depth-1">
   
<?php  		
			$image_name=$row['Name'];
			$image_path=$row['img'];

			
		echo "<h5>{$row['BlogTitle']}</h5> ".
		"  {$row['CreationDate']}<br>";
		echo "<img src=../".$image_name."/".$image_path." height=250 width=100%><br>";
		 
		 echo 
		 "<i><b>CATEGORY:</i></b>{$row['BlogCate']} <br> ".
		 "<i><b>Author:</i></b>{$row['BlogAuthor']}<br>".
		 "<i><b>DESCRIPTION: </i></b>{$row['BlogDesc']} <br>";
		 echo "<br> <br>";
		 ?>
	<div class="post-index z-depth-1">
	<ul class="collection">
	<?php 	
		$query="select * from comment where BID='$a'";
		$res=mysqli_query($conn,$query);
		
		while($ans=mysqli_fetch_assoc($res))
		{
			echo"
				<li class 'collection-item'>
				<p class='com_title'>Comment by:".$ans['fname']."
				<p class='com_body'>".$ans['comm']."</p>
				</li>
				";
		}
		echo "
			<li class='collection-item lime lighten-4'>
			<form action='comment.php?id=".$a."' method='POST'>
			<input type='text' name='comment'>
			<input type='submit' value='Comment' name='com'>
			</form>
			</li>
			";
		?>
		</ul>
		</div>
</div>
<?php
		 
}
}
?>
						
		      		
		      	
				
		      </div>

<div class="col s12 m4 l4">
		      	
		      	<div class="widget-item z-depth-1">
		      		<b>Categories</b>
		      		<div>
		      			<ul class="collection">
					        <a href="entertainment.php" class="collection-item">Entertainment</a>
					        <a href="politics.php" class="collection-item">Politics</a>
					        
					        <a href="economy.php" class="collection-item">Economy</a>
					        <a href="sports.php" class="collection-item">Sports</a>
					      </ul>
		      		</div>
		      	</div>
		      </div>
		    </div>
        </div>

  	  	<footer>
          <div class="footer-copyright">
            <div class="container">
            © 2014 Copyright Text
            <a class="grey-text text-lighten-4 right" href="#!">About Me</a>
            </div>
          </div>
        </footer>

    	<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      	<script type="text/javascript" src="js/materialize.min.js"></script>
      	<script type="text/javascript">
      		$(document).ready(function(){
		      $('.materialboxed').materialbox();
		    });

		    setInterval(function(){ toast('New Post', 4000) }, 7000);
      	</script>
		
    </body>
	
</html>

