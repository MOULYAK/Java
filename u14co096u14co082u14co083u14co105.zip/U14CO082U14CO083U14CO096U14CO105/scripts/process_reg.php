<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";


$fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['uname'];
$pswd=$_POST['pwd'];
$cpwd=$_POST['cpwd'];
$mail=$_POST['email'];
$startdate=date('y-m-d h:i:s');
$enddate=date('y-m-d',strtotime("+30 days"));
$_SESSION['edate']=$enddate;
$qr="insert into reg values('','$fname','$lname','$uname','$pswd','$cpwd','$mail','$startdate','$enddate','')";
if($pswd==$cpwd)
{
	if ($conn->query($qr) === TRUE)
	{
		//echo "New record created successfully";
		header("location:login.html");
	}
	else
	{
		echo "Error: " . $qr . "<br>" . $conn->error;
	}
}
else
{
	$msg="Password does not match!!";
	echo"<script type='text/javascript'>alert('$msg');</script>";
}
$squ="select UserID,Firstname,Username,Email from reg";
$result = $conn->query($squ);
if($conn->error) exit($conn->error); 

if(! $result )
{
  die('Could not get data: ' . mysql_error());
}

while($row = $result->fetch_assoc())
{
	$_SESSION["UserID"]=$row['UserID'];
	$_SESSION["Firstname"]=$row['Firstname'];
	$_SESSION["Username"]=$row['Username'];
	$_SESSION["Email"]=$row['Email'];
}
?>