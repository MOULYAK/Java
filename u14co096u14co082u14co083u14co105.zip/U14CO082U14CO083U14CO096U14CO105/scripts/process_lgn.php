<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}


if($_SERVER["REQUEST_METHOD"] == "POST")
{
			$mail=$_POST['email'];
			//$pswd=$_POST['pwd'];
			$pcheck=$_POST['ptxt'];
			$_SESSION["mail"]=$mail;
			
			$qr="SELECT Password,UserID,Firstname FROM reg where Email='$mail'";
			$res=$conn->query($qr);
			 if($conn->error) exit($conn->error); 
			
			
				if($res->num_rows>0)	
				{
						
						while($row = $res->fetch_assoc()) 
						{	
							if($pcheck=='123' && $mail=='admin@yahoo.com')
							{
								$_SESSION["UserID"]=$row["UserID"];
								//echo $_SESSION["id"];
								$_SESSION["fname"]=$row["Firstname"];
								header("location: admin.php");
							}
							else if($pcheck==$row["Password"])
							{
								$_SESSION["UserID"]=$row["UserID"];
								//echo $_SESSION["id"];
								$_SESSION["fname"]=$row["Firstname"];
								header("location: userpage.php");
								
							}
							else
							{
								
								
								
								header("location:loginagain.html");
								$msg="Password does not match!!";
								echo"<script type='text/javascript'>alert('$msg');</script>";
								break;
								
								
							}
						  
						}
				} 
				else 
				{
						$message ="Please register first!";
						echo"<script type='text/javascript'>alert('$message');</script>";
						header("location:login.html");
				}

}
?>