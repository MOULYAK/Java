<?php
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
//$mail=$_POST['email'];

?>
<html>
<body>
<form name="posting" method="POST" action="blogmaster.php" enctype="multipart/form-data">
<center><h2><b><i>Hello!Write your new blog.</h2></b></i><br><br><br>
Title:&nbsp &nbsp &nbsp &nbsp
<input type="text" name="title" size="50"></input>
<br>
Category:<select name="cate">
<option value="Entertainment">Entertainment</option>
<option value="Science">Science</option>
<option value="Maths">Maths</option>
<option value="Sports">Sports</option>
<option value="Politics">Politics</option>
<option value="Economy">Economy</option>
<option value="Books">Books</option>
</select><br>
<textarea rows="10" cols="100" name="desc">
WRITE YOUR BLOG HERE...
</textarea>
<br>

  <input name="image" type="file" id="image"></input>
  
<br>
<input type="submit" value="POST" name="upload"></input>
</center>
</form>
</body>
</html> 