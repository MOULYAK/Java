<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
//$mail=$_POST['email'];


//$_SESSION["mail"];
?>
<html>
<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
      	<link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
      	<link type="text/css" rel="stylesheet" href="../css/style.css">
</head>
<body>
<nav>
    <div class="nav-wrapper">
      <a href="admininfo.php" class="brand-logo right">Welcome,<?php echo "$_SESSION[fname]";?></a>
      <ul id="nav-mobile" class="left hide-on-med-and-down">
        <li><a href="homepageadmin.php">All blogs</a></li>
        <li><a href="myblogsadmin.php">My blogs</a></li>
		<li><a href="controls.php">Controls</a></li>
		<li><a href="admin.php">Write new blog</a></li>
		<li><a href="logout.php"><i class="mdi-action-view-module left"></i>logout</a></li>
        
      </ul>
    </div>
  </nav>
  
 
<form name="posting" method="POST" action="blogmasteradmin.php" enctype="multipart/form-data">
<center>
Title:
<input type="text" name="title" ></input>
<br>

 <label><b>Category</label></b>
    <select class="browser-default" name="cate">
      <option value="" disabled selected>Choose your option</option>
      <option value="Entertainment">Entertainment</option>
	  <option value="Science">Science</option>
	  <option value="Maths">Maths</option>
	  <option value="Sports">Sports</option>
<option value="Politics">Politics</option>
<option value="Economy">Economy</option>
<option value="Books">Books</option>
    </select>
                       
 
<br>
<textarea rows="10" cols="100" name="desc">
WRITE YOUR BLOG HERE...
</textarea><br>

  <input name="image" type="file" id="image"></input>
  
<br>
<input type="submit" value="POST" name="upload"></input>
</center>
</form>
</body>
  </html>