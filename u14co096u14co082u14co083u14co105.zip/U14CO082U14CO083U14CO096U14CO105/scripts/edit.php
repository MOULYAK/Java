<?php
session_start();
?>
<html>
    <head>
    	<title>MY BLOGS</title>
    	<meta name="viewport" content="width=device-width, initial-scale=1"/>
      	<link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
      	<link type="text/css" rel="stylesheet" href="../css/style.css">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    </head>
<body>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
//echo "Connected successfully";
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	//echo"$id";
	$res=mysqli_query($conn,"select * from blogmaster where Blog_ID='$id'");
	if(!$res)
	{
		die(mysql_error());
	}
	//$row=mysqli_fetch_array($res);
	//echo $res;
	while($row=mysqli_fetch_assoc($res))
{ ?> 
<nav>
    <div class="nav-wrapper">
      <a href="bloggerinfo.php" class="brand-logo right">Welcome,<?php echo "$_SESSION[fname]";?></a>
      <ul id="nav-mobile" class="left hide-on-med-and-down">
        
		<li><a href="logout.php"><i class="mdi-action-view-module left"></i>logout</a></li>
        
      </ul>
    </div>
  </nav>
  
 <div style="margin=30px;padding-left:150px;width:1200px;height:100px;">
<form name="edit" method="POST" action="edit.php" enctype="multipart/form-data">
<center>

Title:
<input type="text" name="ntitle" value="<?php echo $row['BlogTitle'];?>"><br>

<br>

 <label><b>Category</label></b>
    <select class="browser-default" name="ncate">
		<option value="<?php echo $row['BlogCate'];?>" ><?php echo $row['BlogCate'];?></option>
		<option value="Entertainment">Entertainment</option>
		<option value="Sports">Sports</option>
		<option value="Politics">Politics</option>
		<option value="Economy">Economy</option>
		
    </select>
                       
 
<br>
<textarea rows="10" cols="100" name="ndesc"> <?php echo $row['BlogDesc'];?>

</textarea><br>

  <input name="nimage" type="file" id="nimage" >

<br>

<input type="submit" value="Update" name="update"></input>
<input type="hidden" name="id" value="<?php echo $row['Blog_ID'];?>"></input>
</center>
</form>
</div>
<?Php 
}
}?>
<?php
if(isset($_POST['update']))
{   $folder="myimages";
	$image=mysql_real_escape_string($_FILES['nimage']['name']);
	$updateqry="update blogmaster set BlogTitle='$_POST[ntitle]',BlogDesc='$_POST[ndesc]',BlogCate='$_POST[ncate]',Name='$folder',img='$image' where Blog_ID='$_POST[id]'" ; 
	$result=mysqli_query($conn,$updateqry);
	
	header("location:myblogs.php");
}

?>
</body>
</html>