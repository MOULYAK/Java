<?php
session_start();
?>
<html>
    <head>
    	<title>MY BLOGS</title>
    	<meta name="viewport" content="width=device-width, initial-scale=1"/>
      	<link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
      	<link type="text/css" rel="stylesheet" href="../css/style.css">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    </head>
<body>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$author=$_SESSION['fname'];
$uid=$_SESSION['UserID'];
$sql = "select UserID,Firstname,Lastname,Username,Password,Email from reg where UserID=$uid";
$result = mysqli_query($conn,$sql);
if(! $result )
{
  die('Could not get data: ' . mysql_error());
}
?>
<nav>
    <div class="nav-wrapper">
      <a href="bloggerinfo.php" class="brand-logo right">Welcome,<?php echo "$_SESSION[fname]";?></a>
      <ul id="nav-mobile" class="left hide-on-med-and-down">
        <li><a href="homepageuser.php">All blogs</a></li>
        <li><a href="myblogs.php">My blogs</a></li>
		<li><a href="userpage.php">Write new blog</a></li>
		<li><a href="logout.php"><i class="mdi-action-view-module left"></i>logout</a></li>
        
      </ul>
    </div>
  </nav>
  

<div class="container">
			<div class="row">
		      <div class="col s12 m8 l8">
<?php
while($row = mysqli_fetch_assoc($result))
{
	
	?>

   <div class="post-index z-depth-1">
   <font color='blue' align='center' size=3>
   <?php
		echo"<i><b>USER-ID:{$row['UserID']}<br>".
		" <i><b>FIRSTNAME: {$row['Firstname']}<br>".
		 "<i><b>LASTNAME:{$row['Lastname']} <br> ".
		 "<i><b>USERNAME:{$row['Username']}<br>".
		 "<i><b>PASSWORD:{$row['Password']} <br>".
		 "<i><b>EMAIL:{$row['Email']}<br>";
		 ?>
	</font>	 
	</div>
<?php 

}
?>
 </div>

		    </div>
        </div>

  	  	

    	<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      	<script type="text/javascript" src="js/materialize.min.js"></script>
      	<script type="text/javascript">
      		$(document).ready(function(){
		      $('.materialboxed').materialbox();
		    });

		    setInterval(function(){ toast('New Post', 4000) }, 7000);
      	</script>
		


</body>
</html>