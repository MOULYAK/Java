<html>
<body>
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

if(isset($_GET['id']))
{
	
$id=$_GET['id'];
}
//echo $_POST['com'];
if(isset($_POST['com']))
{
$co=$_POST['comment'];
//$q="select BlogAuthor from blogmaster where Blog_ID=$id";
//$r=mysqli_query($conn,$q) or die(mysql_error());
//$row=mysqli_fetch_assoc($r);
//$fn=$row['BlogAuthor'];
$a=$_SESSION['UserID'];
//echo $a;
$q="select Firstname from reg where UserID='$a'";
$r=mysqli_query($conn,$q);
$ro=mysqli_fetch_assoc($r);
$fn=$ro['Firstname'];
//echo "hi";
$qry="insert into comment values('$id','$fn','$co')";
$res=mysqli_query($conn,$qry); 
//echo $res or die(mysql_error());
if($res)
{	
//echo $co;
header('location:homepageuser.php');
}
else
{
	echo"error deleting records".mysqli_error($conn);
}
}
?>
</body>
</html>