<html>
<body>
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

if(isset($_GET['id']))
{
	
$id=$_GET['id'];
//echo"$id";
$q="select BlogAuthor from blogmaster where BlogAuthor='Admin'";
$r=mysqli_query($conn,$q);
$row=mysqli_fetch_assoc($r);
$user=$row['BlogAuthor'];
$qry=("delete from blogmaster where Blog_ID='$id'");
//mysql_select_db('blog');
$res=mysqli_query($conn,$qry) ;
//echo "$res" or die(mysql_error());
if($res && $user!='Admin')
{	
header('location:myblogs.php');
}
else if($res && $user=='Admin')
{
	header('location:myblogsadmin.php');
}
else
{
	echo"error deleting records".mysql_error($conn);
}
}
?>
</body>
</html>