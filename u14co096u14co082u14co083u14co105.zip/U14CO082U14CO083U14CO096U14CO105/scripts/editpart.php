/*if(isset($_POST['ntitle']))
{
	$ntitle=$_POST['ntitle'];
	$bid=$_POST['id'];
	$sql="update blogmaster set BlogTitle='$ntitle' where Blog_ID='$bid'";
	$res=mysql_query($sql) or die(mysql_error());
}
if(isset($_POST['ncate']))
{
	$cate=$_POST['ncate'];
	$bid=$_POST['id'];
	$sql="update blogmaster set BlogCate='$cate' where Blog_ID='$bid'";
 	$res=mysql_query($sql) or die(mysql_error());
}
if(isset($_POST['ndesc']))
{
	$desc=$_POST['ndesc'];
	$bid=$_POST['id'];
	$sql="update blogmaster set BlogDesc='$desc' where Blog_ID='$bid'";
 	$res=mysql_query($sql) or die(mysql_error());
}
if(isset($_POST['nimage']))
{
	$img=$_POST['nimage'];
	$bid=$_POST['id'];
	$sql="update blogmaster set img='$img' where Blog_ID='$bid'";
 	$res=mysql_query($sql) or die(mysql_error());
}
	
	//echo "<meta http-equiv='refresh' content='0;url=myblogs.php'>";
 */