<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
//$mail=$_POST['email'];


//$_SESSION["mail"];
?>
<html>
<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
      	<link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
      	<link type="text/css" rel="stylesheet" href="../css/style.css">
</head>
<body>
<nav>
    <div class="nav-wrapper">
      <a href="bloggerinfo.php" class="brand-logo right">Welcome,<?php echo "$_SESSION[fname]";?></a>
      <ul id="nav-mobile" class="left hide-on-med-and-down">
        <li><a href="homepageuser.php">All News</a></li>
        <li><a href="myblogs.php">My News</a></li>
		<li><a href="userpage.php">Write new News</a><li>
		<li><a href="logout.php"><i class="mdi-action-view-module left"></i>logout</a></li>
        
      </ul>
    </div>
  </nav>
  
 <div style="margin=30px;padding-left:150px;width:1200px;height:100px;">
<form name="posting" method="POST" action="blogmaster.php" enctype="multipart/form-data" >
<center>
Title:
<input type="text" name="title" ></input>
<br>

 <label><b>Category</label></b>
    <select class="browser-default" name="cate">
      <option value="" disabled selected>Choose your option</option>
      <option value="Entertainment">Entertainment</option>
	  <option value="Sports">Sports</option>
	  <option value="Politics">Politics</option>
	 <option value="Economy">Economy</option>
	</select>
                       
 
<br>Write here
<textarea rows="10" cols="50" name="desc">

</textarea><br>

  <input name="image" type="file" id="image"></input>
  
<br><br><br>
<input type="submit" value="POST" name="upload"></input>
</center>
</form>
</div>
</body>
  </html>