<!DOCTYPE html>
<html>
<head>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}

li {
    float: left;
}

a:link, a:visited {
    display: block;
    width: 120px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: #98bf21;
    text-align: center;
    padding: 4px;
    text-decoration: none;
    text-transform: uppercase;
}
a:hover, a:active {
    background-color: #7A991A;
}
</style>
</head>
<body>

<ul>
  <li><a href="dreg.html">SIGNUP</a></li>
  <li><a href="login.html">LOGIN</a></li>
  <li><a href="#contact">Contact</a></li>
  <li><a href="#about">About</a></li>
</ul>

</body>
</html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}

echo "<center><h1> ALL BLOGS!!</h1><br></center>";
//mysql_select_db("blog",$conn);
//$select_query = "SELECT 'ImageURL' FROM  'imagetable' ORDER by 'Image_ID' DESC";
//$sql = mysql_query($select_query) or die(mysql_error());	
//while($row = mysql_fetch_array($sql,MYSQL_BOTH))
//{
//<table style="border-collapse: collapse; font: 12px Tahoma;" border="1" cellspacing="5" cellpadding="5">
//<tbody><tr>
//<td>

//<img src="<?php echo $row[" ImageURL"];="" ?="">" alt="" / ?php>"

//</td>
//</tr>
//</tbody></table>

//}

$sql = "SELECT BlogTitle,BlogDesc,BlogCate,CreationDate FROM blogmaster";


$result = $conn->query($sql);
if($conn->error) exit($conn->error); 

if(! $result )
{
  die('Could not get data: ' . mysql_error());
}
while($row = $result->fetch_assoc())
{
    echo "TITLE :{$row["BlogTitle"]}  <br> ".
		 "DESCRIPTION: {$row["BlogDesc"]} <br>".
         "CATERGORY : {$row["BlogCate"]} <br> ".
         
		 "CREATIONDATE :{$row["CreationDate"]}<br>"
         ;
		 echo "<br> <br>";
}


?>