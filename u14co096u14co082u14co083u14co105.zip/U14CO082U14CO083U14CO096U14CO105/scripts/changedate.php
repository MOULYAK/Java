<?php
session_start();
?>
<html>
    <head>
    	<title>MY BLOGS</title>
    	<meta name="viewport" content="width=device-width, initial-scale=1"/>
      	<link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
      	<link type="text/css" rel="stylesheet" href="../css/style.css">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    </head>
<body>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
//echo "Connected successfully";
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	//echo"$id";
	$res=mysqli_query($conn,"select * from blogmaster where Blog_ID='$id'");
	if(!$res)
	{
		die(mysql_error());
	}
	//$row=mysqli_fetch_array($res);
	//echo $res;
	while($row=mysqli_fetch_assoc($res))
{ ?> 
<nav>
    <div class="nav-wrapper">
      <a href="#" class="brand-logo right">Welcome,<?php echo "$_SESSION[fname]";?></a>
      <ul id="nav-mobile" class="left hide-on-med-and-down">
        
		<li><a href="logout.php"><i class="mdi-action-view-module left"></i>logout</a></li>
        
      </ul>
    </div>
  </nav>
  	
<form name="changedate" method="POST" action="changedate.php" enctype="multipart/form-data">
<center>

UpdateDate:
<input type="date" name="udate"><br>

<br>


<input type="submit" value="Update" name="update"></input>
<input type="hidden" name="id" value="<?php echo $row['Blog_ID'];?>"></input>
</center>
</form>
<?Php 
}
}?>
<?php
if(isset($_POST['update']))
{   
	$updateqry="update blogmaster set UpdateDate='$_POST[udate]' where Blog_ID='$_POST[id]'" ; 
	$result=mysqli_query($conn,$updateqry);
	
	header("location:controls.php");
}

?>
</body>
</html>