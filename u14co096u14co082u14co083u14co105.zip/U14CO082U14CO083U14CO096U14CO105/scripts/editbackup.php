<html>
<body>
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

if(isset($_GET['id']))
{
$id=$_GET['id'];
if(isset($_POST['upload']))
{
$title=$_POST['title'];
$cate=$_POST['cate'];
$desc=$_POST['desc'];
//$pic=$_POST['image'];
$query3=mysql_query("update blogmaster set BlogTitle='$title', BlogCate='$cate',BlogDesc='$desc' where Blog_ID='$id'");
if($query3)
{
header('location:myblogs.php');
}
}
$query1=mysql_query("select * from blogmaster where Blog_ID='$id'");
$query2=mysql_fetch_assoc($query1);
?>
<form method="post" action="">
Title:<input type="text" name="title" value="<?php echo $query2['title']; ?>" /><br />
category:<input type="text" name="cate" value="<?php echo $query2['cate']; ?>" /><br />
Description:<input type="text" name="desc" value="<?php echo $query2['desc']; ?>" /><br />

<br />
<br />
<input type="submit" name="upload" value="update" />
</form>
<?php
}
?>
</body>
</html>
