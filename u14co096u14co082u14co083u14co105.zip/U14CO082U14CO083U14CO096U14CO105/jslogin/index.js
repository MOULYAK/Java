$('#toggle-login').click(function(){
  $('#login').toggle();
});