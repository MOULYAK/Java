<?php
header("location:scripts/homepage.php");
?>