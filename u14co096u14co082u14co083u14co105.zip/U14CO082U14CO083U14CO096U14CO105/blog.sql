-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2016 at 06:13 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `UID` int(100) NOT NULL,
  `active_inactive` tinyint(1) NOT NULL,
  `changedate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`UID`, `active_inactive`, `changedate`) VALUES
(0, 1, '2016-09-29'),
(12, 1, '2016-09-29'),
(18, 1, '2016-09-29'),
(18, 1, '2016-09-29'),
(10, 1, '2016-09-29'),
(11, 0, '2016-10-03');

-- --------------------------------------------------------

--
-- Table structure for table `blogger_info`
--

CREATE TABLE IF NOT EXISTS `blogger_info` (
  `userid` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `isactive` varchar(30) NOT NULL,
  `startdate` date NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastdate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `blogmaster`
--

CREATE TABLE IF NOT EXISTS `blogmaster` (
  `Blog_ID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `BlogTitle` varchar(100) NOT NULL,
  `BlogDesc` varchar(2000) NOT NULL,
  `BlogCate` varchar(20) NOT NULL,
  `BlogAuthor` varchar(20) NOT NULL,
  `Blog_is_active` tinyint(1) NOT NULL,
  `CreationDate` date NOT NULL,
  `UpdateDate` date NOT NULL,
  `Name` varchar(50) NOT NULL,
  `img` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blogmaster`
--

INSERT INTO `blogmaster` (`Blog_ID`, `UserID`, `BlogTitle`, `BlogDesc`, `BlogCate`, `BlogAuthor`, `Blog_is_active`, `CreationDate`, `UpdateDate`, `Name`, `img`) VALUES
(99, 10, 'Science -The innovation', 'Science  is a systematic enterprise that builds and organizes knowledge in the form of testable explanations and predictions about the universe. In an older and closely related meaning, science also refers to this body of knowledge itself.\r\n', 'Science', 'kiran', 1, '2015-08-30', '2016-02-04', 'myimages', 'sc2.jpg'),
(100, 10, 'Maths tricks', 'Mathematicians seek out patterns and use them to formulate new conjectures. Mathematicians resolve the truth or falsity of conjectures by mathematical proof. When mathematical structures are good models of real phenomena.\r\n', 'Maths', 'kiran', 1, '2015-08-30', '2016-07-05', 'myimages', 'm1.jpg'),
(101, 11, 'Political issues', 'A variety of methods are employed in politics, which include promoting or forcing ones own political views among people, negotiation with other political subjects, making laws, and exercising force, including warfare against adversaries. \r\n', 'Politics', 'mina', 1, '2015-08-30', '2015-09-29', 'myimages', 'p1.jpg'),
(102, 11, 'Just for fun!', '\r\nEntertainment is a form of activity that holds the attention and interest of an audience, or gives pleasure and delight. It can be an idea or a task, but is more likely to be one of the activities or events that have developed over thousands of years specifically for the purpose of keeping an audiences attention.', 'Entertainment', 'mina', 1, '2015-08-30', '2015-09-29', 'myimages', 'e3.jpg'),
(103, 13, 'Economy of India', ' The economic agents can be individuals, businesses, organizations, or governments. Transactions occur when two parties agree to the value or price of the transacted good or service, commonly expressed in a certain currency.This is added..\r\n\r\n', 'Economy', 'uday', 1, '2015-08-30', '2015-09-29', 'myimages', 'eco1.jpg'),
(104, 16, 'Outdoor activities-Sports.', 'Sport (UK) or sports (US) are all forms of usually competitive physical activity which, through casual or organised participation, aim to use, maintain or improve physical ability and skills while providing entertainment to participants, and in some cases, spectators.\r\n', 'Sports', 'asmita', 1, '2015-08-30', '2015-09-29', 'myimages', 's2.jpg'),
(105, 10, 'Books!', 'A book is a set of written, printed, illustrated, or blank sheets, made of ink, paper, parchment, or other materials, fastened together to hinge at one side. A single sheet within a book is a leaf, and each side of a leaf is a page.\r\n', 'Books', 'kiran', 1, '2015-08-30', '2015-09-29', 'myimages', 'b1.jpg'),
(106, 12, 'New scific books!', 'A shop where books are bought and sold is a bookshop or bookstore. Books can also be borrowed from libraries. Google has estimated that as of 2010, approximately 130,000,000 unique titles had been published.\r\n', 'Books', 'mukesh', 1, '2015-08-30', '2015-09-29', 'myimages', 'p2.png'),
(108, 18, 'Blog by admin', 'Here is the blog.A majority are interactive, allowing visitors to leave comments and even message each other via GUI widgets on the blogs, and it is this interactivity that distinguishes them from other static websites.\r\n', 'Entertainment', 'Admin', 1, '2015-08-30', '2015-09-29', 'myimages', 'e1.jpg'),
(109, 10, 'New blog-How to write?', 'Many blogs provide commentary on a particular subject; others function as more personal online diaries; others function more as online brand advertising of a particular individual or company. A typical blog combines text, images, and links to other blogs,', 'Entertainment', 'kiran', 1, '2015-08-30', '2015-09-29', 'myimages', 'sc3.jpg'),
(110, 11, 'Today Blog', 'hello\r\n', 'Entertainment', 'mina', 1, '2015-09-03', '2015-10-03', 'myimages', 's1.jpg'),
(114, 20, 'Night', 'WRITE HERE', 'Books', 'kiran', 1, '2015-09-04', '2015-10-04', 'myimages', 'eco1.jpg'),
(115, 20, 'Todays blog', 'This is it!\r\n', 'Entertainment', 'kiran', 1, '2015-09-07', '2017-02-04', 'myimages', 'e2.jpg'),
(116, 12, 'It is good!', 'So,blog it\r\n', 'Books', 'mukesh', 1, '2015-09-07', '2015-10-07', 'myimages', 'b2.jpg'),
(117, 21, 'God Ram', 'God is great!\r\n', 'Science', 'monika', 1, '2015-09-07', '2015-10-07', 'myimages', 'b3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `blog_106`
--

CREATE TABLE IF NOT EXISTS `blog_106` (
  `Fname` varchar(15) NOT NULL,
  `Lname` varchar(15) NOT NULL,
  `Username` varchar(10) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `ConfirmPassword` varchar(20) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `Active-Inactive` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `BID` int(11) NOT NULL,
  `fname` varchar(25) NOT NULL,
  `comm` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`BID`, `fname`, `comm`) VALUES
(113, 'asmita', 'good blog'),
(114, 'kiran', 'NICE BLOG'),
(99, 'Admin', 'Nice science blog.'),
(114, 'kiran', 'great....'),
(102, 'kiran', 'cool'),
(101, 'kiran', 'cool'),
(104, 'monika', 'Good!!!');

-- --------------------------------------------------------

--
-- Table structure for table `doit`
--

CREATE TABLE IF NOT EXISTS `doit` (
  `username` varchar(12) NOT NULL,
  `password` int(10) NOT NULL,
  `firstname` varchar(10) NOT NULL,
  `lastname` varchar(10) NOT NULL,
  `emailid` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doit`
--

INSERT INTO `doit` (`username`, `password`, `firstname`, `lastname`, `emailid`) VALUES
('s', 0, 'moulya', 'iye', 'moulya@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `imagetable`
--

CREATE TABLE IF NOT EXISTS `imagetable` (
  `Image_ID` int(11) NOT NULL,
  `ImageURL` varchar(200) NOT NULL,
  `SubmissionDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE IF NOT EXISTS `reg` (
  `UserID` int(11) NOT NULL,
  `Firstname` varchar(15) NOT NULL,
  `Lastname` varchar(15) NOT NULL,
  `Username` varchar(10) NOT NULL,
  `Password` varchar(25) NOT NULL,
  `Confirmpassword` varchar(25) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Startdate` date DEFAULT NULL,
  `Enddate` date DEFAULT NULL,
  `Activeinactive` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`UserID`, `Firstname`, `Lastname`, `Username`, `Password`, `Confirmpassword`, `Email`, `Startdate`, `Enddate`, `Activeinactive`) VALUES
(12, 'mukesh', 'sharma', 'mukesh', '1', '1', 'muk@yahoo.com', '2015-08-25', '2015-09-24', 0),
(13, 'uday', 'sharma', 'uday', '1', '1', 'udsharma@yahoo.com', '2015-08-25', '2015-09-24', 0),
(14, 'priya', 'sharma', 'priya', '1', '1', 'py@yahoo.com', '2015-08-26', '2015-09-25', 0),
(15, 'Smita', 'Shah', 'Smita', '1', '1', 'sm@yahoo.com', '2015-08-26', '2015-09-25', 0),
(16, 'asmita', 'kumar', 'kumar', '1', '1', 'asmitakumar@ymail.com', '2015-08-29', '2015-09-28', 0),
(18, 'Admin', 'Blog', 'Admin', '123', '123', 'admin@yahoo.com', '2015-08-29', '2015-09-28', 0),
(19, 'vasudev', 'sharma', 'vasu', '1', '1', 'vasu@yahoo.com', '2015-09-03', '2015-10-03', 0),
(20, 'kiran', 'sharma', 'dixi', '1', '1', 'kiran42@yahoo.com', '2015-09-04', '2015-10-04', 0),
(21, 'monika', 'Rathod', 'Shree', '1', '1', 'rj@gmail.com', '2015-09-07', '2015-10-07', 0),
(22, 'moulya', '', 'srini', '1', '1', 'sm@yahoo.com', '2015-09-07', '2015-10-07', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogger_info`
--
ALTER TABLE `blogger_info`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `blogmaster`
--
ALTER TABLE `blogmaster`
  ADD PRIMARY KEY (`Blog_ID`), ADD KEY `UserID` (`UserID`), ADD KEY `UserID_2` (`UserID`);

--
-- Indexes for table `imagetable`
--
ALTER TABLE `imagetable`
  ADD PRIMARY KEY (`Image_ID`);

--
-- Indexes for table `reg`
--
ALTER TABLE `reg`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogger_info`
--
ALTER TABLE `blogger_info`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `blogmaster`
--
ALTER TABLE `blogmaster`
  MODIFY `Blog_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=118;
--
-- AUTO_INCREMENT for table `imagetable`
--
ALTER TABLE `imagetable`
  MODIFY `Image_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `reg`
--
ALTER TABLE `reg`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
