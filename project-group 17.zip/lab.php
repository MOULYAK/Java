<html>
<head>
<title>LABS DATA</title>
<style>
body{
      background-image:url("lab.jpg");
}

</style>
</head>
<body>
<h2 align="center">LAB DETAILS</h2>
<script>
  function validate()
{
      var id=document.getElementById('ID').value;
      var name=document.getElementById('NAME').value;
      var re=/^[\w ]+$/;
     
      if(name==""||name==null)
    {
       alert("NAME IS EMPTY");
       return false;
    }
      if(!re.test(name))
    {
       alert("ERROR NAME CONTAINS INVALID CHARACTERS");
       return false;
    }
     if(id==""||id==null)
    {
       alert("ID IS EMPTY");
       return false;
    }
    if(!re.test(id))
    {
       alert("ERROR ID CONTAINS INVALID CHARACTERS");
       return false;
    }

  return true;
}
</script>
 
<form  name="lab_file" action="laboutput.php" method="post" enctype="multipart/form-data" onsubmit="return validate();" >
<table align="center">
<tr>
<td>Lab ID</td>
<td>:</td>
<td><input type="text" name="ID" id="ID" size="25"></td>
</tr>
<tr>
<td>Lab NAME</td>
<td>:</td>
<td><input type="text" name="NAME" id="NAME" size="25"></td>
</tr>
</table>
<p align="center"><input type="submit" value="SUBMIT">  <input type="reset" value="RESET"></p>
</form>
</body>
</html>