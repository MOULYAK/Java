<html>
<head>
<title>COMPUTER DATA</title>
<style>

body
   {
        background-image:url("lab5.jpg");
   }
h1{
    color:#FF00FF;
font-style:italic;
    }
td{
   color:#66CCFF;
}
</style>
</head>
<body>
<script>
function validate()
{
   var id=document.getElementById('ID').value;
   var name=document.getElementById('NAME').value;
   var position=document.getElementById('POSITION').value;
   var labid=document.getElementById('LABID').value; 
   var re=/^[\w]+$/;
   var rs=/^[0-9]+$/;
   if(id==""||id==null)
   {
     alert("ID IS EMPTY");
     return false;
   }
   if(!re.test(id))
   {
     alert("ERROR: ID CONTAINS INVALID CHARACTERS");
     return false;
   }
   if(name==""||name==null)
   {
     alert("NAME IS EMPTY");
     return false;
   }
   if(!re.test(name))
   {
     alert("ERROR: NAME CONTAINS INVALID CHARACTERS");
     return false;
   } 
   if(position==""||position==null)
   {
     alert("POSITION IS EMPTY");
     return false;
   }
   if(!rs.test(position))
   {
     alert("ERROR:POSITION CONTAINS INVALID CHARACTERS");
     return false;
   }
return true;
} 
</script>   
<?php
   $read=file("lab.txt");
   $count=1;
   $id=array();
   $name=array();
   $i=0;
   $j=0;
   foreach($read as $fname)
          {
                 switch($count)
                     {
                           case 1: {
                                         $id[$i]=$fname;
                                         $count++;
                                         $i++;
                                    }
                                   break;
                           case 2: {
                                          $name[$j]=$fname;
                                          $count=1; 
                                          $j++;
                                    }
                                   break;
                       }
         }
   echo count($id);
   $labid=array_unique($id);
?>
                                   
            
<h1 align="center">COMPUTER DETAILS</h1>
<form  name="computer_file" action="computer_out.php" method="post" enctype="multipart/form-data" onsubmit="return validate();" >
<table align="center">
<tr>
<td>Computer ID</td>
<td>:</td>
<td><input type="text" name="ID" id="ID" size="25"></td>
</tr>
<tr>
<td>Computer NAME</td>
<td>:</td>
<td><input type="text" name="NAME" id="NAME" size="25"></td>
</tr>
<tr>
<td>POSITION</td>
<td>:</td>
<td><input type="text" name="POSITION" id="POSITION" size="25"></td>
</tr>
<tr>
<td>LAB ID</td>
<td>:</td>
<td><select  name="LABID" id="LABID">
    <option selected="selected"><h4>choose one lab id</h4></option>
    <?php
       
       foreach($labid as $fname)
       {
            ?>
             <option value="<?php echo $fname ?>"> <?php echo $fname ?> </option>
     <?php
       }
       ?>
 </select>
</td>
</tr>

</table>
<p align="center"><input type="submit" value="SUBMIT">  <input type="reset" value="RESET"></p>
</form>
</body>
</html>