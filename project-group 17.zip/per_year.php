<?php
session_start();
?>
<html>
<head>
<title>per computer details</title>
<style>
body{
      background-color:#CC3366;
      }
th{
     text-align:center;
     color:white;
     font-size:20px;
   }
td{
   text-align:center;  
     color:white;
     font-size:20px;
  }

</style>
</head>
<body>
<table border=0 width=90%>
<?php
$a=array();
$b=array();
$id=array();
$mon=array();
$y=array();
$a=$_SESSION['c_id'];
$mon=$_SESSION['month'];
$y=$_SESSION['year'];

$p=0;
$q=0;
$check=array();


$id=array_filter(array_map("trim",$a),"strlen");
echo "<tr>
  <th>Maintenance year</th>
  <th>Computer id</th>
  </tr>";

  for($i=1;$i<count($y);$i++)
     {
       for($p=0;$p<count($check);$p++)
        {
             if($check[$p]==$i)
              {
                $q++;
               }
          }
  if($q==0)
{
       $k=0;
               for($j=1;$j<count($y);$j++)
                {
                       
                        echo "<tr>";
       
                        if(strcmp($y[$i],$y[$j])==0)
                           {
                                 $k++;
                                $check[$p]=$j;
                                 $p++;
                               if($k==1)
                                    {
                                        echo "<td>$y[$i]</td>";
                                     }
                               else
                                      echo "<td></td>";
                                       echo "<td> $id[$j] </td>";
                               }
                             echo "</tr>";
                      }
         }
    $q=0;
         }

?>
</table>
<br/><br/>

<form  name="per computer" action="report.html" method="post" enctype="multipart/form-data">
      
<p align="center" > <input  type="submit" value="GO TO REPORTS"></p>
</form>
<form  name="per computer1" action="menu.php" method="post" enctype="multipart/form-data">

<p align="center"> <input type="submit" value="GO TO MENU "></p>
</form>
</body>
</html>