<!DOCTYPE html>
<html>
<head>
<title>php project</title>
<style>
body{
 
    background-image:url("lab1.jpg");
  
}
</style>
</head>
<body>
<h1 align="center">COMPUTER LAB MANAGEMENT SYSTEM</h1>
<form name="lab" action="lab.php" method="post" enctype="multipart/form-data">
<p align="center">
<input style="color:black;font-weight:5px;font-size:15px;background-color:white;" type="submit" value="ADD LAB"></p>
</form>
<form name="computer" action="computer.php" method="post" enctype="multipart/form-data">
<p align="center">
<input style="color:black;font-weight:5px;font-size:15px;background-color:white;" type="submit" value="ADD COMPUTER"></p>
</form>
<form name="maintenance" action="maintenance.php" method="post" enctype="multipart/form-data">
<p align="center">
<input style="color:black;font-weight:5px;font-size:15px;background-color:white;" type="submit" value="ADD MAINTENANCE DETAILS"></p>
</form>
<form name="report" action="report.html" method="post" enctype="multipart/form-data">
<p align="center">
<input style="color:black;font-weight:5px;font-size:15px;background-color:white;" type="submit" value="REPORTS"></p>
</form>
</body>
</html>