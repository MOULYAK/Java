<?php
session_start();
?>

<?php
if($_SERVER["REQUEST_METHOD"]=="POST")
{ 
  $myFile="maintenance.txt";
$fh=fopen($myFile,'a');
fwrite($fh,"\r\n");
$c=implode(",",$_POST);
fwrite($fh,$c);

fclose($fh);

  $a=array();
  $b=array();
  $c=array();
  $d=array();
  $e=array();
  $f=array();
  $handle=@fopen("maintenance.txt","r");
  $i=0;
  if($handle)
     {
        while(!feof($handle))
          {
            $buffer=fgets($handle);
            list($a[$i],$b[$i],$c[$i])=split(",",$buffer);
            $d[$i]=$a[$i];
            $e[$i]=$b[$i]; 
            $f[$i]=$c[$i];
            $i++;
            
          }
          echo "<br> <br>";
      }

$_SESSION['c_id']=$d;
$_SESSION['month']=$f;
$_SESSION['year']=$e;

$_SESSION['umonth']=array_unique($f);
header("Location:success.html");


}
?>