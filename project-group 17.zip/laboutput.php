<html>
<head>
<title> LABOUTPUT </title>
</head>
<body>
<table border = "0" width = "100%">
<?php
$name = $_POST["NAME"];
$id = $_POST["ID"];

/*creating text file*/

$handle = fopen("lab.txt",'a');

fwrite($handle,$id."\n");
fwrite($handle,$name."\n");

//Write data success
//closing file
	fclose($handle);
header("Location:success.html");

?>
</table>
</body>
</html>