<?php
session_start();
?>
<html>
<head>
<title>per computer details</title>
<style>

body{
     background-color:#CCCCFF;
     }

th{
     text-align:center;
     color:blue;
   }
td{
     text-align:center;
     color:red;
  }
   
</style>
</head>
<body>
<table border=1 color="green" width=100%>
<?php
$id=array();
$mon=array();
$y=array();
$id=$_SESSION['c_id'];
$mon=$_SESSION['month'];
$y=$_SESSION['year'];

echo "<tr>
   <th>Computer id</th>
   <th>Maintenance month</th>
   <th>Maintenance year</th>
   </tr>";

for($i=1;$i<count($id);$i++)
{ 
   echo "<tr>
         <td>$id[$i]</td>
         <td>$mon[$i]</td>
         <td>$y[$i]</td>
         </tr>";
}
?>
</table>
<form  name="per computer" action="report.html" method="post" enctype="multipart/form-data">
      
<p align="center"> <input  type="submit" value="GO TO REPORTS"></p>
</form>
<form  name="per computer1" action="menu.php" method="post" enctype="multipart/form-data">

<p align="center"> <input type="submit" value="GO TO MENU "></p>
</form>
</body>
</html>