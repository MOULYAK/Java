<?php
  session_start();
?>
<html>
<head>
<title>MAINTENANCE DATA</title>
<style>

body
   {
        background-image:url("calendar2.jpg");
   }
h1{
    color:white;
font-style:italic;
    }
</style>

</head>
<body>
<script>
function validate()
{
    var c_id=document.getElementById('ID').value;
   var month=document.getElementById('MONTH').value;
   var year=document.getElementById('YEAR').value;
   var re=/^[\w]+$/;
   var rs=/^[0-9]+$/;
   var l=year.length;
   if(c_id=="select")
   {
     alert("SELECT AN ID");
     return false;
   }
    if(month=="selected")
   {
     alert("SELECT A MONTH");
     return false;
   }
    if(year==""||year==null)
   {
     alert("YEAR IS EMPTY");
     return false;
   }
   if(!rs.test(year))
   {
     alert("ERROR:YEAR CONTAINS INVALID CHARACTERS");
     return false;
   }
   if(l!=4)
    {
       alert("ERROR:YEAR SHOULD FOUR DIGITS");
       return false;
     }
return true;
} 
    
</script>
<?php
  $a=array();
  $a=$_SESSION['comp_id'];
  $b=array_filter(array_map("trim",$a),"strlen");
?>
<br /><br /><br />
<h1 align="center">MAINTENANCE DETAILS</h1>
<form  name="maintenance_file" action="maintenanceoutput.php" method="post" enctype="multipart/form-data" onsubmit="return validate();" >
<br /><br />
<table align="center">

<tr>
<td>COMPUTER ID</td>
<td>:</td>
<td>
  <select name="ID" id="ID">
  <option value="select">select computer id</option>
  <?php
       
      foreach($b as $fname)
       {
              ?>
             <option value="<?php echo $fname ?>"> <?php echo $fname ?> </option>
     <?php
       }
       ?>
 </select>
 </td>
</tr>

<tr>
<td>MAINTENANCE YEAR</td>
<td>:</td>
<td><input type="text" name="YEAR" id="YEAR" size="25"></td>
</tr>       

<tr>
<td>MAINTENANCE MONTH</td>
<td>:</td>
<td><select  name="MONTH" id="MONTH" >
     <option value="selected">select a month</option>
     <option value="January">January</option>
     <option value="February">February</option>
     <option value="March">March</option>
     <option value="April">April</option>
     <option value="May">May</option>
     <option value="June">June</option>
     <option value="July">July</option>
     <option value="August">August</option>
     <option value="September">September</option>
     <option value="October">October</option>
     <option value="November">November</option>
     <option value="December">December</option>
    </select>
</td>
</tr>

</table>
<br />
<p align="center"><input type="submit" value="SUBMIT"> <input type="reset" value="RESET"></p>
</form>
</body>
</html>