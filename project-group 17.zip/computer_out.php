<?php
 session_start();
?>
<?php
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$a=array();
$b=array();
$c=array();
$d=array();
$e=array();
$check=0;
 $handle=@fopen("computer.txt","r");
 $i=0;
    $labid=$_POST['LABID'];
    $position=$_POST['POSITION'];
    if($handle)
    {
        while(!feof($handle))
          {
            $buffer=fgets($handle);
            list($a[$i],$b[$i],$c[$i],$d[$i])=split(",",$buffer);
             $e[$i]=$a[$i];
             if(strcmp($labid,$d[$i])==0&&strcmp($position,$c[$i])==0)
              {
                     $check=1;
                      break;
                }
             $i++;
            }
          
          echo "<br> <br>";
     }

if($check==1)header("Location:computer.php");
else
{
$myFile="computer.txt";
$fh=fopen($myFile,'a');
fwrite($fh,"\n");
$d=implode(",",$_POST);
fwrite($fh,$d);


fclose($fh);
$_SESSION['comp_id']=$e;
header("Location:success.html");
}
fclose($handle);
}
?>
