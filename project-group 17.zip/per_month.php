<?php
session_start();
?>
<html>
<head>
<title>per computer details</title>
<style>
body{
      background-color:#CC3366;
      }
th{
     text-align:center;
     color:white;
     font-size:20px;
   }
td{
   text-align:center;  
     color:white;
     font-size:20px;
  }

</style>
</head>
<body>
<table border=0 width=80%>
<?php
$id=array();
$mon=array();
$y=array();
$id=$_SESSION['c_id'];
$mon=$_SESSION['month'];
$y=$_SESSION['year'];
$check=array();
$p=0;
$q=0;
$r=0;

 echo "<tr>
<th>Maintenance month</th>
<th>Computer id</th>
</tr>";
 for($i=1;$i<count($mon);$i++)
    {
          
      $k=0;     
            for($r=0;$r<count($check);$r++)
              {
                 if($check[$r]==$i)
                   {
                         $q++;
                    }
                }
              if($q==0)
            {
             
             for($j=1;$j<count($mon);$j++)
              {
                         
                          echo "<tr>";
                        
                           if(strcmp($mon[$i],$mon[$j])==0)
                             {
                                 $k++;
                                $check[$p]=$j;
                                  ++$p;
                                  if($k==1)
                             {
                                      
                                      echo "<td>$mon[$i]</td>";
                                      
                              }
                          else 
                                  {
                                       echo "<td></td>";
                                   }
                                 echo "<td> $id[$j]</td>";
                              }
                          echo "</tr>";
                 }
            } 
$q=0;  
 }
?>
</table>
<br/><br/>
<form  name="per computer" action="report.html" method="post" enctype="multipart/form-data">
      
<p align="center" > <input  type="submit" value="GO TO REPORTS"></p>
</form>
<form  name="per computer1" action="menu.php" method="post" enctype="multipart/form-data">

<p align="center"> <input type="submit" value="GO TO MENU "></p>
</form>
</body>
</html>
