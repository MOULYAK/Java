
public class CreatingThread extends Thread
{
    public void run()
	{
	 System.out.println("Thread starts Running");
	 
	}
	public static void main(String[] args)
	{
	  CreatingThread t1= new CreatingThread();
	  t1.start();
	  //t1.start();
	  CreatingThread t2= new CreatingThread();
	  t2.start();
	 /* try {
		Thread.sleep(15000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
	 // t1.start();
	}
}