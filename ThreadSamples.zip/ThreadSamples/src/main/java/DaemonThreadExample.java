
public class DaemonThreadExample extends Thread{
	 public void run(){  
		  if(Thread.currentThread().isDaemon()){//checking for daemon thread  
		   System.out.println("Daemon thread ");  
		  }  
		  else{  
		  System.out.println("User Thread");  
		 }  
		 }  
		 public static void main(String[] args){  
			 DaemonThreadExample t1=new DaemonThreadExample();//creating thread  
			 DaemonThreadExample t2=new DaemonThreadExample();  
			 DaemonThreadExample t3=new DaemonThreadExample();  
			 //t2.start();
		  t2.setDaemon(true);//now t2 is daemon thread  
		    
		  t1.start();//starting threads  
		 // t2.start();  
		  t3.start();  
		 }  

}
