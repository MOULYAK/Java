public class CreatingThreadByRunnable implements Runnable{
  public void run()
	{
	 System.out.println("Thread starts Running");
	 
	}
	public static void main(String[] args)
	{
	  CreatingThreadByRunnable t1= new CreatingThreadByRunnable();
	  Thread m=new Thread(t1);
	  m.start();
	 // t1.start();
	}

}