
public class ThreadJoiningExample extends Thread {
	public void run(){  
		  for(int i=1;i<=5;i++){  
		   try{  
		    Thread.sleep(1000);  
		   }catch(Exception e){System.out.println(e);}  
		  System.out.println(i);  
		  }  
		 }  
		public static void main(String args[]){  
			ThreadJoiningExample t1=new ThreadJoiningExample();  
			ThreadJoiningExample t2=new ThreadJoiningExample();  
			ThreadJoiningExample t3=new ThreadJoiningExample();  
		 t1.start();  
		 try{  
		 // t1.join();  
			 t1.join(2000); 
		 }catch(Exception e){System.out.println(e);}  
		  
		 t2.start();  
		 t3.start();  
		 } 

}
