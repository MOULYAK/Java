
public class ThreadJoinMethods extends Thread{
	
	public void run(){  
		   System.out.println("running...thread is"+Thread.currentThread().getName());  
		  }  
		 public static void main(String args[]){  
			 ThreadJoinMethods t1=new ThreadJoinMethods();  
			 ThreadJoinMethods t2=new ThreadJoinMethods();  
		  System.out.println("Name of t1:"+t1.getName());  
		  System.out.println("Name of t2:"+t2.getName());  
		  System.out.println("Id of t1:"+t1.getId()); 
		  System.out.println("Id of t2:"+t2.getId());  
		  
		  /*t1.start();  
		  t2.start();  
		  */
		  t1.setName("Moulya");  
		  System.out.println("After changing name of t1:"+t1.getName());  
		  t2.setName("Kotha");  
		  System.out.println("After changing name of t2:"+t2.getName());  
		  
		  t1.start();  
		  t2.start();  
		 }  

}
