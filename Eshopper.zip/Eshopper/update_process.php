<?php



$servername = "localhost";
$username = "root";
$pass_word = "";
$db="shop";
// Create connection
$conn = mysqli_connect($servername, $username, $pass_word,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['update']))
{   
    $startdate=date('y-m-d h:i:s');
	//$folder="myimages";
	//$image=mysql_real_escape_string($_FILES['nimage']['name']);
	$upload_image=addslashes($_FILES["image"][ "name" ]);
			
					$folder="products";

					move_uploaded_file(addslashes($_FILES["image"]["tmp_name"]), "$folder".addslashes($_FILES["image"]["name"]));
	$updateqry="UPDATE product SET cat_ID='$_POST[cate]',prod_image='$upload_image',prod_path='$folder',prod_name='$_POST[name]',prod_desc='$_POST[desc]',price='$_POST[price]',available='$_POST[avail]',add_date='$startdate' where prod_ID='$_POST[id]' " ; 
	$result=mysqli_query($conn,$updateqry) or die(mysqli_error($conn));
	if($result){
	header("location:admin.php");
	
	}
	else{
        echo $updateqry;
		echo "wrong";
	}
}
else
{
	echo "not successfull";
}
?>