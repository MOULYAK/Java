<?php



$servername = "localhost";
$username = "root";
$pass_word = "";
$db="shop";
// Create connection
$conn = mysqli_connect($servername, $username, $pass_word,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
 if(isset($_GET['id']))
 {
	 $id=$_GET['id'];
	 echo $id;
	 $sql="SELECT * FROM product ";

	$result= mysqli_query($conn,$sql);
	
    if(! $result){
		die("could not get data: ". mysqli_error());
	}
	
	?>
	<?php
	while($row=mysqli_fetch_assoc($result))
	{
		$quan=$row['quan'];
		$price=$row['price'];
		$avail=$row['available'];
		$email="moulyakota2@gmail.com";
		
	}
			$qr="insert into cart values('$id','$quan',1,'$email')";
			if ($conn->query($qr) == TRUE)
	                {
		                   //echo "New item added successfully";
		                  header("location:index.html");
	                 }

 }
 else{
	 echo "Not functioning";
 }
?>