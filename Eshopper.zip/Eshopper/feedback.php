<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="Shop";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


?>
<!DOCTYPE html>
<html lang="en" ng-app="fetch">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | Online Grocery Shopping</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
	            <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.24/angular.min.js"></script>
				<style>
				.product-image-wrapper img{
				      width:170px;
					  height:170px;
				    }
					.col-sm-6 img{
					width:420px;
					  height:250px;
					    }
					</style>

	<script>
	var fetch=angular.module('fetch',[]);
	fetch.controller('dbCtrl',['$scope','$http',function ($scope, $http) {
            $http.get("ajax.php")
                .success(function(data){
                    $scope.data = data;
                })
                .error(function() {
                    $scope.data = "error in fetching data";
                });
        }]);
		
</script>
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href="#"><i class="fa fa-phone"></i> +91 95 01 888 821</a></li>
								<li><a href="#"><i class="fa fa-envelope"></i> info@domain.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="admin.php"><img src="images/home/logo.png" alt="" /></a>
						</div>
						<div class="btn-group pull-right">
							<div class="btn-group">
								<h2 align="center"> Online Grocery Shopping</h2>
								
							</div>
							
							
						</div>
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<li><a href="admin.php"><i class="fa fa-home"></i> Home</a></li>
								<li><a href="adminadd.php" class="active"><i class="fa fa-plus-square"></i> ADD PRODUCT</a></li>
								<li><a href="feedback.php"><i class="fa fa-comments-o"></i> Feedback</a></li>
								<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>

							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
		</header>
		<section id="cart_items">
				<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Name</td>
							<td class="description">Comment</td>
							<td class="quantity">Subject</td>
							<td class="total">Email</td>
							<td></td>
						</tr>
					</thead>
					<?php
					 $sql="SELECT * FROM feedback ";

	$result= mysqli_query($conn,$sql);
	
    if(! $result){
		die("could not get data: ". mysqli_error());
	}
	
	
	while($row=mysqli_fetch_assoc($result))
	{
		$mailid=$row['mail_ID'];
		
		$sub=$row['subject'];
		$name=$row['name'];
		$com=$row['msg'];
		
					
					?>
					<tbody>
						<tr>
							<td class="cart_product">
							<h4><?php echo $name ?></h4>
							</td>
							<td class="cart_description">
								<?php echo  $com?>
								
							</td>
							<td class="cart_price">
								<p><?php echo $sub ?></p>
							</td>
							
						<td class="cart_price">
								<p><?php echo $mailid ?></p>
							</td>
							
						</tr>
  <?php
			
	}
  ?>
						
					</tbody>
				</table>
				</section>
			</body>
			</html>
		
		
		
		
		
		
