<?php
error_reporting(0);
header("Access-Control-Allow-Origin: *");   
header("Content-Type: application/json; charset=UTF-8");  
$servername= "localhost";
	  $username= "root";
	  $password= "";
	  $db= "shop";
	  
	  // creating connection
	  $conn = mysqli_connect($servername,$username,$password,$db);
	  
	  // checking connection
	  if(!$conn)
	  {
		  die("connection failed: ".mysqli_connect_error());
	  }
	  echo "hello";

	  $che = "SELECT * FROM product ";  
	  $res= mysqli_query($conn,$che);
	  
	  	
    if(! $res){
		die("could not get data: ". mysqli_error());
	}
	  echo "hello1";
	  
$outp = ""; 
while($rs=mysqli_fetch_assoc($res)) {     
	  echo "hello";

    if ($outp != "") {$outp .= ",";}     
    $outp .= '{"prod_ID":"'  . $rs["prod_ID"] . '",'; 
    $outp .= '"cat_ID":"'   . $rs["cat_ID"]  . '",'; 
    $outp .= '"image":"'   . $rs["prod_image"]  . '",'; 
    $outp .= '"path":"'. $rs["prod_path"]  . '",'; 
	$outp .= '"pname":"'  . $rs["prod_name"] . '",'; 
    $outp .= '"desc":"'   . $rs["prod_desc"]  . '",'; 
    $outp .= '"price":"'   . $rs["price"]  . '",'; 
	$outp .= '"dis":"'   . $rs["dis"]  . '",'; 
    $outp .= '"offer_2":"'   . $rs["offer_2"]  . '",'; 
    $outp .= '"offer_1":"'. $rs["offer_1"]  . '",'; 
	$outp .= '"bundle":"'  . $rs["bundle"] . '",'; 
    $outp .= '"available":"'   . $rs["available"]  . '",'; 
    $outp .= '"quantity":"'   . $rs["quan"]  . '",'; 	
    $outp .= '"date":"'. $rs["add_date"]  . '"}'; 
    } 
$outp ='{"details":['.$outp.']}'; 
echo($outp); 
?> 