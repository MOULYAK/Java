<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db="shop";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
//echo "Connected successfully";


$fname=$_POST['name'];
$mail=$_POST['email'];

//$lname=$_POST['lname'];
$add=$_POST['address'];
$phone=$_POST['phone'];
$pswd=$_POST['pw'];
$cpwd=$_POST['cpw'];
$startdate=date('y-m-d h:i:s');

//$startdate=date('y-m-d');
//$enddate=date('y-m-d',strtotime("+30 days"));
//$_SESSION['edate']=$enddate;
if($pswd==$cpwd)
{
	
	$che="SELECT * from reg WHERE email='$mail'";
	$res= mysqli_query($conn,$che);
	
    if(! $res){
		die("could not get data: ". mysqli_error());
	}
	if($res->num_rows>0)
	{
		$mes1="Enter another email id";
		echo "<script type='text/javascript'>alert('$mes1')</script>";
        echo "<script>setTimeout(\"location.href = 'login.html';\",100);</script>";
	}
	else
	{
      $password=($pswd);
     $qr="insert into reg values('$mail','$password','$fname','$add','$startdate','$phone')";

	if ($conn->query($qr) === TRUE)
	{
		//echo "New record created successfully";
		header("location:login.html");
	}
	else
	{
		echo "Error: " . $qr . "<br>" . $conn->error;
	}
	}
}
else
{
	$msg="Password does not match!!";
	echo"<script type='text/javascript'>alert('$msg');</script>";
		echo "<script>setTimeout(\"location.href = 'login.html';\",100);</script>";

}
	
?>