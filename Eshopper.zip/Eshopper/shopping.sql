-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2017 at 12:01 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
CREATE DATABASE Shop;

USE Shop;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `prod_ID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `buy` tinyint(1) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_ID` int(11) NOT NULL,
  `cat_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_ID`, `cat_name`) VALUES
(1, 'Flowers'),
(2, 'Fruits'),
(3, 'Vegetables'),
(4, 'Herbs and seasonings'),
(5, 'Ayurvedic'),
(6, 'Dhal & pulses'),
(7, 'Dry fruits'),
(8, 'Oil and Ghee'),
(9, 'Masalas and Spices'),
(10, 'Rice products'),
(11, 'Sugar,Salt'),
(12, 'Bread and Bakery'),
(13, 'Eggs'),
(14, 'Cake'),
(15, 'Fruit Drinks & Juices'),
(16, 'Energy & Health Drinks'),
(17, 'Mineral Water'),
(18, 'Soft Drinks'),
(19, 'Tea & Coffee'),
(20, 'Organic Beverages'),
(21, 'Biscuits'),
(22, 'Snacks & Chips'),
(23, 'Chocolates & Cakes'),
(24, 'Sweets'),
(25, 'Baby Food'),
(26, 'Cooking Ingredients'),
(27, 'Dry Fruits,Berries & Nuts'),
(28, 'Chinese'),
(29, 'Soups & Instant Foods'),
(30, 'Baby Care'),
(31, 'Hair Care'),
(32, 'Skin Care'),
(33, 'Deos & Perfumes'),
(34, 'Cleaning Accessories'),
(35, 'Cookware'),
(36, 'Electronics and Electricals'),
(37, 'Detergents'),
(38, 'Plasticware'),
(39, 'Chicken'),
(40, 'Mutton'),
(41, 'Seafood');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `ID` int(11) NOT NULL,
  `desti` varchar(30) NOT NULL,
  `pin` int(6) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `name`  varchar(30) NOT NULL,
  `mail_ID` varchar(30) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `msg` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `prod_ID` int(11) NOT NULL,
  `cat_ID` int(11) NOT NULL,
  `prod_image` varchar(100) NOT NULL,
  `prod_path` varchar(50) NOT NULL,
  `prod_name` varchar(20) NOT NULL,
  `prod_desc` varchar(40) NOT NULL,
  `price` double NOT NULL,
  `dis` double NOT NULL,
  `offer_2` tinyint(1) NOT NULL,
  `offer_1` tinyint(1) NOT NULL,
  `bundle` tinyint(1) NOT NULL,
  `available` int(11) NOT NULL,
  `quan` int(11) NOT NULL,
  `add_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



/*inserting values into product table */
/*fruits and vegetables */
INSERT INTO product VALUES (1,2,'p1.png','products','orange','Enjoy Freshness',40,8,0,0,0,30,1,'2017-04-14');
INSERT INTO product VALUES (2,2,'p2.png','products','Apple','Enjoy Freshness',100,2,0,0,0,30,1,'2017-04-11');
INSERT INTO product VALUES (3,2,'p3.jpg','products','watermelon','Enjoy Freshness',60,4,0,0,0,30,1,'2017-04-13');
INSERT INTO product VALUES (4,2,'p5.jpg','products','Banana','Enjoy Freshness',30,10,0,0,0,50,1,'2017-04-01');
INSERT INTO product VALUES (5,2,'p6.jpg','products','Grapes','Enjoy Freshness',120,0,0,0,0,30,1,'2017-04-08');

INSERT INTO product VALUES (6,3,'p4.jpg','products','Potato','Enjoy Freshness',20,15,0,0,0,30,1,'2017-04-09');
INSERT INTO product VALUES (7,3,'p7.jpg','products','carrot','Enjoy Freshness',40,0,0,0,0,30,1,'2017-04-03');
INSERT INTO product VALUES (8,3,'p8.jpg','products','Broccoli','Enjoy Freshness',40,8,0,0,0,30,1,'2017-03-14');

/*grocery and staples */
INSERT INTO product VALUES (9,6,'g5.jpg','products','Green split peas','Enjoy Freshness',170,0,0,0,0,50,1,'2017-02-14');
INSERT INTO product VALUES (10,6,'g7.png','products','chana Dhal','Enjoy Freshness',80,0,0,0,0,50,1,'2017-02-11');
INSERT INTO product VALUES (11,6,'g8.png','products','Moong Dhal','Enjoy Freshness',50,0,0,0,0,50,1,'2017-02-09');
INSERT INTO product VALUES (12,7,'g1.jpg','products','Dry Fruits','Enjoy Freshness',570,0,0,0,0,50,1,'2017-03-22');













-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE `reg` (
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `address` varchar(40) NOT NULL,
  `do_reg` date NOT NULL,
  `phone_no` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------
INSERT INTO `reg` (`email`, `password`, `user_name`, `address`, `do_reg`, `phone_no`) VALUES
('admin@yahoo.com', 'Grocery1', 'Admin', 'Adress of the store', '2017-04-15', 9299353328),
('monika@gmail.com', 'Monika@1', 'monika', ' 256,mtb', '2017-04-15', 2147483647),
('moulyakotha2@gmail.com', 'Moulya@97', 'Moulya', ' room no:443\r\nMTB svnit Surat', '2017-04-15', 2147483647),
('teja@gmail.com', 'Teja12', 'teja', ' 789', '2017-04-15', 2147483647);


--
-- Table structure for table `trans`
--

CREATE TABLE `trans` (
  `trans_ID` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `tot_price` double NOT NULL,
  `do_pur` date NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wallet`
--

CREATE TABLE `wallet` (
  `money` double NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`prod_ID`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_ID`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`prod_ID`);

--
-- Indexes for table `reg`
--
ALTER TABLE `reg`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `trans`
--
ALTER TABLE `trans`
  ADD PRIMARY KEY (`trans_ID`),
  ADD KEY `trans_key` (`email`);

--
-- Indexes for table `wallet`
--
ALTER TABLE `wallet`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `prod_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `trans`
--
ALTER TABLE `trans`
  MODIFY `trans_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `trans`
--
ALTER TABLE `trans`
  ADD CONSTRAINT `trans_key` FOREIGN KEY (`email`) REFERENCES `reg` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `wallet`
--
ALTER TABLE `wallet`
  ADD CONSTRAINT `wallet_key` FOREIGN KEY (`email`) REFERENCES `reg` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
