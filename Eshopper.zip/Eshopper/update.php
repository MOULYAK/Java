<?php



$servername = "localhost";
$username = "root";
$pass_word = "";
$db="shop";
// Create connection
$conn = mysqli_connect($servername, $username, $pass_word,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
if(isset($_GET['id']))
{
	$pid=$_GET['id'];
	$sql="SELECT * FROM product WHERE prod_ID='$pid'";
	

	$result= mysqli_query($conn,$sql);
	if(! $result){
		die("could not get data: ". mysqli_error());
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Login | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
<script type="text/javascript">

  function checkForm(form)
  {
    if(form.name.value == "") {
      alert("Error: Username cannot be blank!");
      form.name.focus();
      return false;
    }
    re = /^\w+$/;
	if(/\d/.test(form.name.value))
	        {
		        alert("Name is INVALID ,it should contain only characters");
				form.name.focus();
		        return false;
	        }
   
	
     if(trimAll(form.desc.value )== "") {
      alert("Error: Address cannot be blank!");
      form.desc.focus();
      return false;
    }
	//for phone no
	
	  
	  var phoneno = /[0-9]/; 
	  if(!is(NaN(form.price.value))) {
        alert("Error: price must contain digits only ");
        form.price.focus();
        return false;
      }
     // var phoneno = /^\d/; 
	  if(!is(NaN(form.avail.value))) {
        alert("Error: availability must contain digits only ");
        form.avail.focus();
        return false;
      }
      
    return true;
  }
  function trimAll(sString)
{
    while (sString.substring(0,1) == ' ')
    {
        sString = sString.substring(1, sString.length);
    }
    while (sString.substring(sString.length-1, sString.length) == ' ')
    {
        sString = sString.substring(0,sString.length-1);
    }
return sString;
}

</script>
	</head><!--/head-->

<body>
<style>
label.add{
opacity=0.6;
}
</style>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href=""><i class="fa fa-phone"></i> +91 95 01 888 821</a></li>
								<li><a href=""><i class="fa fa-envelope"></i> info@domain.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href=""><i class="fa fa-facebook"></i></a></li>
								<li><a href=""><i class="fa fa-twitter"></i></a></li>
								<li><a href=""><i class="fa fa-linkedin"></i></a></li>
								<li><a href=""><i class="fa fa-dribbble"></i></a></li>
								<li><a href=""><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.html"><img src="images/home/logo.png" alt="" /></a>
						</div>
						<div class="btn-group pull-right">
							<div class="btn-group">
								<h2 align="center"> Online Grocery Shopping</h2>
								
							</div>
							
							
						</div>
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<li><a href="admin.php"><i class="fa fa-home"></i> Home</a></li>
								<li><a href="adminadd.php" class="active"><i class="fa fa-plus-square"></i> ADD PRODUCT</a></li>
								<li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		
	</header><!--/header-->
	<?php
		  while($row=mysqli_fetch_assoc($result))
      { ?>
	<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Add an item</h2>
						<form name="login_form" onsubmit="return checkForm(this);" action="update_process.php"  method="POST"enctype="multipart/form-data">
							<select  name="cate" required>
                          <option value="<?php echo $row['cat_ID'];?>" >Choose your category</option>
                          <option value="1">Flowers</option>
	                      <option value="2">Fruits</option>
						   <option value="3">Vegetables</option> 
						   <option value="4">Herbs and seasonings</option>
						   <option value="5">Ayurvedic</option>
						   <option value="6">Dhal & pulses</option> 
						   <option value="7">Dry fruits</option>
						   <option value="8">Oil and Ghee</option>
						   <option value="9">Masalas and Spices</option> 
						   <option value="10">Rice products</option>
						   <option value="11">Sugar,Salt</option>
						   <option value="12">Bread and Bakery</option> 
						   <option value="13">Eggs</option>
						   <option value="14">Cake</option>
						   <option value="15">Fruit Drinks & Juices</option> 
						   <option value="16">Energy & Health Drinks</option>
						   <option value="17">Mineral Water</option>
						   <option value="18">Soft Drinks</option> 
						   <option value="19">Tea & Coffee</option>
						   <option value="20">Organic Beverages</option>
						   <option value="21">Biscuits</option> 
						   <option value="22">Snacks & Chips</option>
						   <option value="23">Chocolates & Cakes</option>
						   <option value="24">Sweets</option> 
						   <option value="25">Baby Food</option>
						   <option value="26">Cooking Ingredients</option>
						   <option value="27">Dry Fruits,Berries & Nuts</option> 
						   <option value="28">Chinese</option>
                           <option value="29">Soups & Instant Foods</option>
						   <option value="30">Baby Care</option> 
						   <option value="31">Hair Care</option>
						   <option value="32">Skin Care</option>
						   <option value="33">Deos & Perfumes</option> 
						   <option value="34">Cleaning Accessories</option>
						   <option value="35">Cookware</option>
						   <option value="36">Electronics and Electricals</option> 
						   <option value="37">Detergents</option>
						   <option value="38">Plasticware</option>
						   <option value="39">Chicken</option> 
						   <option value="40">Mutton</option>
	                      <option value="41">Seafood</option>
                          </select><br>
						  <br>
						  <input name="image" type="file" id="image" required /> 
						  <input type="text" name="name" placeholder="Product Name" value="<?php echo $row['prod_name'];?>" required/>
						  <textarea rows="2" cols="100" name="desc" placeholder="Product description" required><?php echo $row['prod_desc'];?></textarea><br>
						  <input type="text" name="price" placeholder="Product Price per Kg/Litre" value="<?php echo $row['price'];?>" required/>
						  <input type="text" name="avail" placeholder="Availability" value="<?php echo $row['available'];?>" required/>
						 <h2> 1+1 offer </h2><input type="checkbox"  id="one" name="one" value="<?php echo $row['offer_2'];?>"/>
						 <h2> 2+1 offer </h2><input type="checkbox" id="two" name="two" value="<?php echo $row['offer_1'];?>"/>
						 <h2> bundle  </h2>  <input type="checkbox" id="bundle" name="bundle" value="<?php echo $row['bundle'];?>"/>
						  
                             <input type="hidden" name="id" value="<?php echo $row['prod_ID'];?>"></input>
						  <button type="submit" name="update" class="btn btn-default">Update</button>
						  
							
						</form>
					</div><!--/login form-->
				</div>
				
			</div>
		</div>
	</section><!--/form-->
	<?php
	  }
}
	  ?>
	

  
    <script src="js/jquery.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>