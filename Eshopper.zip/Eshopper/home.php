<?php
$id=$_GET['id'];
?>
 <!DOCTYPE html>
<html lang="en" ng-app="fetch">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | Online Grocery Shopping</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
	            <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.24/angular.min.js"></script>
				<style>
				.product-image-wrapper img{
				      width:170px;
					  height:170px;
				    }
					.col-sm-6 img{
					width:420px;
					  height:250px;
					    }
					</style>

	<script>
	var fetch=angular.module('fetch',[]);
	fetch.controller('dbCtrl',['$scope','$http',function ($scope, $http) {
		$scope.cate=<?php echo json_encode( $id) ?>;
            $http.get("ajax.php")
                .success(function(data){
                    $scope.data = data;
                })
                .error(function() {
                    $scope.data = "error in fetching data";
                });
        }]);
		
</script>
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href="#"><i class="fa fa-phone"></i> +91 95 01 888 821</a></li>
								<li><a href="#"><i class="fa fa-envelope"></i> info@domain.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.html"><img src="images/home/logo.png" alt="" /></a>
						</div>
						<div class="btn-group pull-right">
							<div class="btn-group">
								<h2 align="center"> Online Grocery Shopping</h2>
								
							</div>
							
							
						</div>
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<li><a href="index.html"><i class="fa fa-home"></i> Home</a></li>
								<li><a href="checkout.html"><i class="fa fa-crosshairs"></i> Checkout</a></li>
								<li><a href="cart.html" class="active"><i class="fa fa-shopping-cart"></i> Cart</a></li>
								<li><a href="login.html"><i class="fa fa-lock"></i> Login</a></li>
						        <li><a href="contact-us.html"><i class="fa fa-user"></i> Contact Us</a></li>

							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
		
		
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
					
					</div>
					<div class="col-sm-3"  >
						<div class="search_box pull-right">
							<input type="text" name="sea" ng-model="search" placeholder="Search"/>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	
	
	</header><!--/header-->
	
	<section id="slider"><!--slider-->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
							<li data-target="#slider-carousel" data-slide-to="1"></li>
							<li data-target="#slider-carousel" data-slide-to="2"></li>
				            <li data-target="#slider-carousel" data-slide-to="3"></li>
							<li data-target="#slider-carousel" data-slide-to="4"></li>

						</ol>
						
						<div class="carousel-inner">
							<div class="item active">
								<div class="col-sm-6">
									<h1><span>Grocery</span>-SHOPPER</h1>
									<h2>Welcome To Our Website</h2>
									<p>Shop here in your own way </p>
								</div>
								<div class="col-sm-6">
									<img src="products/big6.jpg" class="girl img-responsive" alt="" />
									
								</div>
							</div>
							<div class="item">
								<div class="col-sm-6">
									<h1><span>Grocery</span>-SHOPPER</h1>
									<h2> Flat 10% DISCOUNT* </h2>
									<p>Only for registered users </p>
									
								</div>
								<div class="col-sm-6">
									<img src="products/big3.jpg" class="girl img-responsive" alt="" />
									
								</div>
							</div>
							<div class="item">
								<div class="col-sm-6">
									<h1><span>Grocery</span>-SHOPPER</h1>
									<h2> Flat 10% DISCOUNT* </h2>
									<p>Only for registered users </p>
								</div>
								<div class="col-sm-6">
									<img src="products/big4.jpg" class="girl img-responsive" alt="" />
								
								</div>
							</div>
							<div class="item">
								<div class="col-sm-6">
									<h1><span>Grocery</span>-SHOPPER</h1>
									<h2> Flat 10% DISCOUNT* </h2>
									<p>Only for registered users </p>
									</div>
								<div class="col-sm-6">
									<img src="products/big5.jpg" class="girl img-responsive" alt="" />
									
								</div>
							</div>
							<div class="item">
								<div class="col-sm-6">
									<h1><span>Grocery</span>-SHOPPER</h1>
									<h2> Flat 10% DISCOUNT* </h2>
									<p>Only for registered users </p>

								</div>
								<div class="col-sm-6">
									<img src="products/cook1.jpg" class="girl img-responsive" alt="" />
									
								</div>
							</div>
							
						</div>
						
						<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>
						<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a>
					</div>
					
				</div>
			</div>
		</div>
	</section><!--/slider-->
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#fruits">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Fruits & Vegetables
										</a>
									</h4>
								</div>
								<div id="fruits" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
										    <li><a href="home.php?id=1">Flowers</a></li>
											<li><a href="home.php?id=2">Fruits </a></li>
											<li><a href="home.php?id=3">Vegetables </a></li>
											<li><a href="home.php?id=4">Herbs and seasonings </a></li>
											
										
										</ul>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#grocery">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Grocery & Staples
										</a>
									</h4>
								</div>
								<div id="grocery" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="home.php?id=5">Ayurvedic</a></li>
											<li><a href="home.php?id=6">Dhal & pulses</a></li>
											<li><a href="home.php?id=7">Dry fruits</a></li>
											<li><a href="home.php?id=8">Oil and Ghee</a></li>
											<li><a href="home.php?id=9">Masalas and Spices</a></li>
											<li><a href="home.php?id=10">Rice products</a></li>
											<li><a href="home.php?id=11">Sugar,Salt</a></li>
											
										</ul>
									</div>
								</div>
							</div>
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#bakery">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Bakery
										</a>
									</h4>
								</div>
								<div id="bakery" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="home.php?id=12">Bread and Bakery </a></li>
											<li><a href="home.php?id=13">Eggs</a></li>
											<li><a href="home.php?id=14">Cake</a></li>
								
										</ul>
									</div>
								</div>
							</div>
							
							
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#bevarages">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Bevarages
										</a>
									</h4>
								</div>
								<div id="bevarages" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="home.php?id=15">Fruit Drinks & Juices </a></li>
											<li><a href="home.php?id=16">Energy & Health Drinks</a></li>
											<li><a href="home.php?id=17">Mineral Water</a></li>
							                <li><a href="home.php?id=18">Soft Drinks</a></li>
											<li><a href="home.php?id=19">Tea & Coffee</a></li>
											<li><a href="home.php?id=20">Organic Beverages</a></li>

								
										</ul>
									</div>
								</div>
							</div>
							
							
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#brandedfoods">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Branded Foods
										</a>
									</h4>
								</div>
								<div id="brandedfoods" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="home.php?id=21">Biscuits </a></li>
											<li><a href="home.php?id=22">Snacks & Chips</a></li>
											<li><a href="home.php?id=23">Choclates & Cakes</a></li>
							                <li><a href="home.php?id=24">Sweets</a></li>
											<li><a href="home.php?id=25">Baby food</a></li>
											<li><a href="home.php?id=26">Cooking Ingredients</a></li>
										    <li><a href="home.php?id=27">Dry Fruits,Berries & Nuts</a></li>
											<li><a href="home.php?id=28">Chinese</a></li>
                                            <li><a href="home.php?id=29">Soups & Instant Foods</a></li>

								
										</ul>
									</div>
								</div>
							</div>
							
							
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#care">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Personal Care
										</a>
									</h4>
								</div>
								<div id="care" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="home.php?id=30">Baby Care </a></li>
											<li><a href="home.php?id=31">Hair Care</a></li>
											<li><a href="home.php?id=32">Skin Care</a></li>
							                <li><a href="home.php?id=33">Deos & Perfumes</a></li>
											

								
										</ul>
									</div>
								</div>
							</div>
							
							
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#household">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											House Hold
										</a>
									</h4>
								</div>
								<div id="household" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="home.php?id=34">Cleaning Accessories </a></li>
											<li><a href="home.php?id=35">Cookware</a></li>
											<li><a href="home.php?id=36">Electronics and Electricals</a></li>
							                <li><a href="home.php?id=37">Detergents</a></li>
											<li><a href="home.php?id=38">Plasticware</a></li>
											

								
										</ul>
									</div>
								</div>
							</div>
							
							
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#meat">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Meat
										</a>
									</h4>
								</div>
								<div id="meat" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="home.php?id=39">Chicken </a></li>
											<li><a href="home.php?id=40">Mutton</a></li>
											<li><a href="home.php?id=41">Seafood</a></li>
							                
											

								
										</ul>
									</div>
								</div>
							</div>
							
							
							
							
							
							
							
							
						</div><!--/category-products-->
					
						
					
						
						<div class="price-range"><!--price-range-->
							<h2>Price Range</h2>
							<div class="well text-center">
								 <input type="text" class="span2" value="" data-slider-min="0" data-slider-max="1000" data-slider-step="5" data-slider-value="[500,1000]" id="sl2" ><br />
								 <b class="pull-left">Rs 0</b> <b class="pull-right">Rs 1000</b>
							</div>
						</div><!--/price-range-->
						
						<div class="shipping text-center"><!--shipping-->
							<img src="images/home/shipping.jpg" alt="" />
						</div><!--/shipping-->
					
					</div>
				</div>
				
				<div class="col-sm-9 padding-right">
					<div class="features_items" ng-controller="dbCtrl"  ng-model="searchFilter" ><!--features_items-->
						<h2 class="title text-center">Features Items</h2>
						<div class="col-sm-4" ng-repeat="x in data | filter : search | filter : {cat_ID: cate} " >
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="{{x.prod_path}}/{{x.prod_image}}" alt="{{x.prod_path}}" />
											<h2>Rs {{x.price}}</h2>
											<p>{{x.prod_name}}</p>
											<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>Rs {{x.price}}</h2>
												<p>{{x.prod_name}}</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
											</div>
										</div>
								</div>
							
							</div>
						</div>						
					</div><!--features_items-->
					
					<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">recommended items</h2>
						
						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
								<div class="item active">	
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="products/d9.jpg" alt="" />
													<h2>Rs 40</h2>
													<p>Sauce soya</p>
													<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
												</div>
												
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="products/k1.jpg" alt="" />
													<h2>Rs 100</h2>
													<p>Cookies</p>
													<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
												</div>
												
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="products/pickle1.jpg" alt="" />
													<h2>Rs 200</h2>
													<p>Mango Pickle</p>
													<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
												</div>
												
											</div>
										</div>
									</div>
								</div>
								<div class="item">	
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="products/s3.jpg" alt="" />
													<h2>Rs 68</h2>
													<p>Scents</p>
													<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
												</div>
												
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="products/s2.jpg" alt="" />
													<h2>Rs 150</h2>
													<p>Olay Face Cream</p>
													<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
												</div>
												
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="products/s11.jpg" alt="" />
													<h2>Rs 150</h2>
													<p>Fogg Scent</p>
													<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
												</div>
												
											</div>
										</div>
									</div>
								</div>
							</div>
							 <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							  </a>
							  <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
								<i class="fa fa-angle-right"></i>
							  </a>			
						</div>
					</div><!--/recommended_items-->
					
				</div>
			</div>
		</div>
	</section>
	
	<!--<footer id="footer"><!--Footer
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2><span>e</span>-shopper</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor</p>
						</div>
					</div>
					<div class="col-sm-7">
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="images/home/iframe1.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="images/home/iframe2.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="images/home/iframe3.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="images/home/iframe4.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="address">
							<img src="images/home/map.png" alt="" />
							<p>505 S Atlantic Ave Virginia Beach, VA(Virginia)</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Service</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Online Help</a></li>
								<li><a href="#">Contact Us</a></li>
								<li><a href="#">Order Status</a></li>
								<li><a href="#">Change Location</a></li>
								<li><a href="#">FAQ’s</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Quock Shop</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">T-Shirt</a></li>
								<li><a href="#">Mens</a></li>
								<li><a href="#">Womens</a></li>
								<li><a href="#">Gift Cards</a></li>
								<li><a href="#">Shoes</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Policies</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Terms of Use</a></li>
								<li><a href="#">Privecy Policy</a></li>
								<li><a href="#">Refund Policy</a></li>
								<li><a href="#">Billing System</a></li>
								<li><a href="#">Ticket System</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Company Information</a></li>
								<li><a href="#">Careers</a></li>
								<li><a href="#">Store Location</a></li>
								<li><a href="#">Affillate Program</a></li>
								<li><a href="#">Copyright</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3 col-sm-offset-1">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<form action="#" class="searchform">
								<input type="text" placeholder="Your email address" />
								<button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
								<p>Get the most recent updates from <br />our site and be updated your self...</p>
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div>-->
	<footer>	
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright © 2017 Grocery-SHOPPER Inc. All rights reserved.</p>
					<p class="pull-right">Designed by <span><a target="_blank" href="index.html">Students</a></span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	

  
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>