<?php
//database settings
$connect = mysqli_connect("localhost", "root", "", "Shop");
$result = mysqli_query($connect, "select distinct * from  product join category on product.cat_ID=category.cat_ID  ");

$data = array();

while ($row = mysqli_fetch_array($result)) {
  $data[] = $row;
}
    print json_encode($data);
?>