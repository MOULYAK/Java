<?php
//database settings
//session_start();
//$id=$_SESSION['cat_id'];
$id=$_GET['id'];
echo $id;
$connect = mysqli_connect("localhost", "root", "", "Shop");
$result = mysqli_query($connect, "select distinct * from  product   where cat_ID='$id' ");

$data = array();

while ($row = mysqli_fetch_array($result)) {
  $data[] = $row;
}
    print json_encode($data);
	header("location:home.html");
?>