#include <stdio.h>
#include <stdlib.h>
#include<math.h>
struct stu
{
    int arr_time;
    int cpu_time;
    int p_id;
    struct stu *next;
}*queue;

void display()
{
    struct stu *p;
    p=queue;
    while(p!=NULL)
    {
        printf("\n%d %d %d\n",p->arr_time,p->cpu_time,p->p_id);
        p=p->next;
    }
}

void sort(void)
{
    struct stu *temp,*p,*q;
    p=queue;
    temp=(struct stu *)malloc(sizeof(struct stu));
    
    int i,j;
    while(p!=NULL)
    {
        q=queue;
        while(q!=NULL)
        {
            if(p->arr_time<q->arr_time)
            {
                
                temp->arr_time=p->arr_time;
                temp->cpu_time=p->cpu_time;
                temp->p_id=p->p_id;
                p->arr_time=q->arr_time;
                p->cpu_time=q->cpu_time;
                p->p_id=q->p_id;
                q->arr_time=temp->arr_time;
                q->cpu_time=temp->cpu_time;
                q->p_id=temp->p_id;
            }
            else if(p->arr_time==q->arr_time && p->cpu_time<=q->cpu_time)
            {
                
                temp->arr_time=p->arr_time;
                temp->cpu_time=p->cpu_time;
                temp->p_id=p->p_id;
                p->arr_time=q->arr_time;
                p->cpu_time=q->cpu_time;
                p->p_id=q->p_id;
                q->arr_time=temp->arr_time;
                q->cpu_time=temp->cpu_time;
                q->p_id=temp->p_id;
            }
            q=q->next;
        }
        p=p->next;    
    }
}

void readyRT(int n)
{
    
    struct stu *p,*temp;
    int i;
    for(i=0;i<n;i++)
    {
        p=queue;
        while(p->cpu_time==0)
            p=p->next;
        if(p->cpu_time!=0)
            printf("Running Process:%d\n",p->p_id);
        temp=p->next;
        if(temp!=NULL)
            printf("Ready Queue: ");
        while(temp!=NULL)
        {
            printf(" %d |",temp->p_id);
            temp=temp->next;
        }
        printf("\n\n");
        p->cpu_time=p->cpu_time-1;
        while(p!=NULL)
        {
            if(p->arr_time<=i)
            {
                p->arr_time=p->arr_time+1;
            
            }
            p=p->next;
        }
        sort();
    }
}

void readyJF(int m)
{
   struct stu *p,*temp;
    int i;
    for(i=0;i<m;i++)
    {
        p=queue;
        while(p->cpu_time==0)
            p=p->next;
        if(p->cpu_time!=0)
            printf("Running Process:%d\n",p->p_id);
        temp=p->next;
        if(temp!=NULL)
            printf("Ready Queue: ");
        while(temp!=NULL)
        {
            printf(" %d |",temp->p_id);
            temp=temp->next;
        }
        printf("\n\n");
       p->cpu_time=p->cpu_time-1;
        while(p!=NULL)
        {
            if(p->arr_time<=i)
            {
                p->arr_time=p->arr_time+1;
            
            }
            p=p->next;
        }
        sort();
    }

    

}


int main()
{
    int no,i,at,ct,sum=0,ch;
    struct stu *p;
    queue=(struct stu *)malloc(sizeof(struct stu));
    printf("Enter the no. of processes :");
    scanf("%d",&no);
printf(" 1.SJF\n 2.SRTF\n 3.EXIT\n");
printf("\n Enter choice");
scanf("%d",&ch);
switch(ch)
{

case 1://printf("Enter burst time of each process ");

 for(i=0;i<no;i++)
    {
        struct stu *q=(struct stu *)malloc(sizeof(struct stu));
        //scanf("%d",&ct);
        ct=rand()%15+1;
        q->cpu_time=rand()%10+1;
        q->p_id=i+1;
        q->next=NULL;
        if(i==0)
        {
            queue=q;
            p=q;
        }
        else
        {
            p->next=q;
            p=p->next;    
        }
        sum+=ct;    
    }
 printf("\nGiven processes with their id");
    display();
    printf("\n\n");
sort();
    readyJF(sum);
break;

    case 2: printf("Enter the arrival time and burst time of each process ");
    for(i=0;i<no;i++)
    {
        struct stu *q=(struct stu *)malloc(sizeof(struct stu));
        //scanf("%d %d",&at,&ct);
        at=rand()%9;
        ct=rand()%15+1;
        q->arr_time=at;
        q->cpu_time=ct;
        q->p_id=i+1;
        q->next=NULL;
        if(i==0)
        {
            queue=q;
            p=q;
        }
        else
        {
            p->next=q;
            p=p->next;    
        }
        sum+=ct;    
    }

    printf("\nGiven processes with their id");
    display();
    printf("\n\n");
    sort();
    readyRT(sum);
break;
case 3:exit;
break;
default : printf("\n Enter valid choice");
break;
}
    return 0;
}


