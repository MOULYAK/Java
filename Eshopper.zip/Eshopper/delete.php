<?php



$servername = "localhost";
$username = "root";
$pass_word = "";
$db="shop";
// Create connection
$conn = mysqli_connect($servername, $username, $pass_word,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_GET['id']))
{
	$pid=$_GET['id'];
	$sql="DELETE FROM product WHERE prod_ID='$pid'";
	

	$result= mysqli_query($conn,$sql);
	if($result)
	{
		echo "successfully deleted";
		 header("location:admin.php");
	}
}

?>