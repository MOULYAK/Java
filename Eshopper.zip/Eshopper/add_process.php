<?php



$servername = "localhost";
$username = "root";
$pass_word = "";
$db="shop";
// Create connection
$conn = mysqli_connect($servername, $username, $pass_word,$db);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['upload']))
{   
    $startdate=date('y-m-d h:i:s');
	//$folder="myimages";
	//$image=mysql_real_escape_string($_FILES['nimage']['name']);
	$upload_image=addslashes($_FILES["image"][ "name" ]);
			
					$folder="products";

					move_uploaded_file(addslashes($_FILES["image"]["tmp_name"]), "$folder".addslashes($_FILES["image"]["name"]));
	$updateqry="INSERT INTO product VALUES ('',$_POST[cate],'$upload_image','$folder','$_POST[name]','$_POST[desc]','$_POST[price]',0,'$_POST[two]','$_POST[one]','$_POST[bundle]','$_POST[avail]',1,'$startdate')" ; 
	$result=mysqli_query($conn,$updateqry);
	if($result){
	header("location:admin.php");
	
	}
}
?>